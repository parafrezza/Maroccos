# Morocco Player

Player controllato via HTTP / UDP / TCP / (facoltativo) OSC con fade Brightness+Contrast (opzionale Saturation in modalità strict), playlist, preload/take, scheduling, wallpaper informativo Linux e sistema di aggiornamento.

## Avvio rapido
```
python morocco_player/main.py --host 0.0.0.0 --http 8081 --udp 5000 --tcp 5001 --osc 5002 --udp-respond
```
Oppure (dalla cartella del player):
```
python main.py
```

File di configurazione opzionale: `settings.txt` (stessa cartella) chiave=valore:
```
HOST=0.0.0.0
HTTP_PORT=8081
UDP_PORT=5000
TCP_PORT=5001
OSC_PORT=5002
UDP_RESPOND=1
API_KEY= (se valorizzato abilita controllo API_KEY per HTTP)
TLS_CERT= (facoltativo, abilita HTTPS)
TLS_KEY=
ALLOWLIST=ip1,ip2 (lista IP ammessi se definita)
DEBUG=1 (log verbosi)
PRODUCTION=1 (abilita watchdog semplice)
VLC_ARGS=--no-video-title-show,--vout=gles2   # opzionale: override argomenti VLC
LINUX_INFO_WALLPAPER=1                       # 0 per disabilitare wallpaper informativo
LINUX_INFO_OVERLAY_SIZE=256x100              # dimensioni riquadro informazioni in alto-sinistra
LINUX_INFO_ROTATE=90                         # ruota wallpaper (clockwise). 0/90/180/270
```
Parametri CLI sovrascrivono le chiavi (es: `--http 9090`).

## Novità / Note Linux
Su Linux viene creata (in background) una finestra Tk nascosta usata come drawable stabile per VLC (assegnata via `set_xwindow`). Il fullscreen forza anche la finestra Tk. Per alcuni modelli di Raspberry/driver, chiamare anche `player.set_fullscreen()` di VLC può causare black screen: per evitarlo lasciamo il controllo alla finestra Tk. Se vuoi forzare anche la chiamata VLC, esporta `LINUX_VLC_SET_FULLSCREEN=1`.

Wallpaper informativo: con `LINUX_INFO_WALLPAPER=1` all'avvio viene generato `wallpaper_info.png`, impostato via pcmanfm. Il contenuto ora include anche la versione (estratta da `manifest.txt` della release corrente o dall'ultimo bundle in `releases/`), oltre a:
- Nome applicazione
- Indirizzi IPv4 (`hostname -I`)
- Timestamp di avvio

Il testo è reso in un overlay posizionato in alto a sinistra; la dimensione è configurabile con `LINUX_INFO_OVERLAY_SIZE` (default `256x100`).

Puoi rigenerare e reimpostare lo sfondo in qualunque momento con `GET /wallpaper/regenerate`.

Desktop minimale (LXDE): endpoint `GET /desktop/minimal?on=1` prova a:
- Abilitare l'autohide del pannello (barra applicazioni)
- Nascondere icone di Cestino, volumi e Home sul desktop
Per ripristinare: `GET /desktop/minimal?on=0`. Alcune impostazioni richiedono il riavvio dei componenti LXDE; il comando tenta `lxpanelctl restart` e `pcmanfm --reconfigure`.

## Struttura
- `main.py` entry point
- `api/controller.py` logica VLC + fade + playlist + download + take + get_ready
- `api/controller_qt.py` (sperimentale) backend Qt multimediale senza VLC (solo funzioni base)
- `api/commands.py` mappa comandi base
- `api/updater.py` gestore aggiornamenti
- `protocols/*_server.py` layer di rete (HTTP / UDP / TCP / OSC)
- `media/` contenuti locali
- `releases/` bundle generati

## Fade & Modalità strict
Il fade regola Brightness & Contrast. Con parametro `strict=1` usa anche Saturation (nero più profondo, saturazione riportata a 1 nel fade-in). Disponibile per: `fadeout`, `fadein`, `black`, `take`.

## Scheduling
Aggiungere `time=secondi` a qualunque comando per ritardarne l'esecuzione. Endpoint utili:
- `schedule_list`
- `schedule_cancel?id=UUID`

## Comandi (HTTP = GET /nome?param=.. | UDP/TCP = "nome k=v ..." | OSC = /nome)
Playback / Fade:
- load (input)
- play / pause / stop
- fadeout (dur,fps,curve,strict)
- fadein  (dur,fps,curve,strict)
- black (dur, on=1/0, strict)
- take (input,dur oppure dur_out,dur_in,fps,curve_out,curve_in,strict)
- preload (input) / preload_clear / take_preloaded
- get-ready (carica tutti i media in playlist, loop on, avvia primo, va a nero immediato)
- loop_one (input opzionale, on=1/0) — esegue un singolo file in loop infinito senza usare la playlist
- status
- fullscreen (on=1/0)

Playlist:
- playlist_add (input)
- playlist_add_all_media
- playlist_play / playlist_next / playlist_prev
- playlist_loop (on=1/0)
- playlist_status

Download:
- download (path=URL singolo)
- download_media (path=URL directory http con listing semplice)

Aggiornamento / Admin:
- version
- admin/update/check (POST JSON)
- admin/update/apply (POST JSON)
- admin/update/status
- admin/update/rollback (POST)
- admin/drain (POST dur)
- admin/undrain (POST)

Wallpaper Linux:
- wallpaper/regenerate (rigenera e reimposta wallpaper informativo)

Debug:
- debug/on, debug/off, debug/status

Esempi:
```bash
# Nero immediato
curl http://localhost:8081/black
# Fade a nero in 1.5s strict
curl "http://localhost:8081/black?dur=1.5&strict=1"
# Carica e take con fade totale 2s
curl "http://localhost:8081/take?input=4.mp4&dur=2"
# Take con tempi separati e strict
curl "http://localhost:8081/take?input=4.mp4&dur_out=1&dur_in=2&strict=1"
# Preparazione rapida (loop + primo avvio + nero)
curl http://localhost:8081/get-ready
# Fullscreen on / off
curl http://localhost:8081/fullscreen?on=1
curl http://localhost:8081/fullscreen?on=0
# Rigenera wallpaper (Linux)
curl http://localhost:8081/wallpaper/regenerate
# Loop un singolo file
curl "http://localhost:8081/loop_one?input=4.mp4&on=1"
# Disabilita loop mantenendo lo stesso file caricato
curl "http://localhost:8081/loop_one?on=0"
```

## Backend Qt sperimentale
È possibile avviare il player con un backend alternativo basato su Qt (PyQt6 o PyQt5) che NON usa VLC.
Obiettivo: prototipare una pipeline video più semplice quando VLC presenta instabilità (es. schermo nero).

Avvio:
```
python main.py --qt
```
oppure esportando la variabile d'ambiente:
```
SET USE_QT=1  (Windows PowerShell: $env:USE_QT=1)
python main.py
```

Stato attuale (limitato):
- Supporta: load, play, pause, stop, fadein/out, black, take, fullscreen, status
- Fading simulato con overlay nero e animazione di opacità (non Brightness/Contrast reali)
- Non supporta ancora: playlist, preload, download, loop_one, get-ready (stubs ritornano not_implemented_qt)
- Status riporta placeholder per brightness/contrast e time/length = null (metadati non ancora interrogati)

Quando usare:
- Per verificare se i problemi di rendering sono specifici del backend VLC
- Per testare fade base e controllo finestra fullscreen

Limitazioni note:
- Codec supportati dipendono dal backend multimediale Qt della piattaforma (potrebbero mancare alcuni formati VLC)
- Nessuna regolazione colore/contrast avanzata
- Nessuna gestione playlist/looping avanzato

Roadmap possibile (non implementata):
- Recupero durata e posizione corrente via segnali mediaStatusChanged
- Implementazione loop_one interno usando posizioneChanged + seek
- Preload semplice caricando nuova sorgente e tenendo overlay nero

Se un comando non supportato viene chiamato sul backend Qt, riceverai: `{ "ok": false, "error": "not_implemented_qt" }`.

## API / Endpoint principali

Nota: gli endpoint HTTP rispondono in JSON. Molte chiamate disponibili anche via UDP/TCP/OSC.

Principali endpoint HTTP:
- `GET /version` — manifest della release corrente (se presente).
- `POST /admin/update/check` — `{ "versions_url": "https://host/versions.json" }` (recupera lista versioni). Internamente ora usa `UpdateManager.check()`.
- `POST /admin/update/apply` — `{ "version":"x.y.z", "url":"https://host/bundle.zip", "sha256":"..." }` + opzionali `service`, `retries`.
- `GET /admin/update/status` — stato update `{ phase, message, version }`.
- `POST /admin/update/rollback` — tentativo rollback.
- `POST /admin/drain` / `POST /admin/undrain` — fadeout / fadein amministrativo.

Esempi:
```bash
curl -H "X-API-KEY: ${API_KEY}" http://localhost:8081/version
curl -X POST -H "Content-Type: application/json" -H "X-API-KEY: ${API_KEY}" \
  -d '{"version":"2025.09.02","url":"https://host/bundle.zip","sha256":"..."}' \
  http://localhost:8081/admin/update/apply
```

## Sistema di aggiornamento (dettagli)

Flusso `apply` in `UpdateManager`:
1. Determina hash atteso: parametro `sha256` o estratto dal nome file `bundle_v<ver>_<sha256>.zip`.
2. Download zip (retry con backoff semplice) + verifica SHA256 se disponibile.
3. Estrazione in staging `releases/v<version>.tmp`.
4. Normalizzazione (flatten se una sola cartella annidata).
5. Lettura `manifest.txt` (campo `sha256=` = content hash del primo pass del bundle generator).
6. Promozione a `releases/v<version>` e switch atomico del symlink `current` (fallback copy su Windows se symlink non supportato).
7. Restart service via `systemctl restart <service>` solo su Linux se `service` fornito (default `morocco-player.service`).
8. Stato finale `phase=ok` (o `warning` se restart fallisce) con ritorno di `zip_sha256` e `manifest_sha256`.

Hash: `zip_sha256` è l'hash dell'archivio finale (incluso manifest aggiornato). `manifest_sha256` rappresenta l'hash dei contenuti (prima dell'inclusione definitiva del manifest con hash). Possono differire.

Percorsi base (auto):
- Linux: `/opt/morocco-player` (fallback `~/.local/share/vlc_remote` se permessi mancanti)
- macOS: `~/Library/Application Support/vlc_remote`
- Windows: `%APPDATA%/vlc_remote`

Metodi pubblici principali:
- `check(versions_url, timeout=10)`
- `apply(version, url, sha256=None, service=None, retries=3)` (sha256 opzionale se nel nome)
- `status_get()`
- `rollback()`

Manifest contiene: version, built_at, app, entry, python_min, sha256 (content hash).

## Aggiornamento: guida rapida passo-passo

Questa sezione riassume in modo pratico cosa fare (e cosa avviene dietro le quinte) per aggiornare il player.

### 1. Generare il bundle
Dal root del progetto (dove c'è `make_bundle.py`):
```
python make_bundle.py
```
Output nella cartella `morocco_player/releases/`:
- `bundle_v<version>_<zipSHA256>.zip` (artefatto finale)
- symlink / copia `latest` e `latest.zip`

Note:
- La `<version>` viene autogenerata timestamp (UTC) se non esiste un file `morocco_player/VERSION` contenente una versione custom.
- `<zipSHA256>` è l'hash dell'archivio finale (comprende il manifest definitivo) e viene già incluso nel nome per facilitare la verifica automatica.
- All'interno dello zip c'è `manifest.txt` con un campo `sha256=` che rappresenta l'hash dei contenuti (prima dell'inserimento dell'hash nel manifest): questo è esposto poi come `manifest_sha256`.

### 2. Pubblicare il bundle
Carica lo zip su un server raggiungibile via HTTP/HTTPS (consigliato HTTPS). Esempio URL finale:
```
https://host/bundles/bundle_v2025.09.03-170000_0123abcd...ff.zip
```
Opzionale: pubblicare anche un `versions.json` per la consultazione remota (endpoint `/admin/update/check`). Esempio minimale:
```json
{
  "versions": [
    {
      "version": "2025.09.03-170000",
      "url": "https://host/bundles/bundle_v2025.09.03-170000_0123...ff.zip",
      "sha256": "0123...ff",
      "notes": "Fix fade jitter"
    }
  ],
  "latest": "2025.09.03-170000"
}
```

### 3. (Opzionale) Verificare elenco versioni
```
curl -X POST -H "Content-Type: application/json" -H "X-API-KEY: ${API_KEY}" \
  -d '{"versions_url":"https://host/versions.json"}' \
  http://<host>:8081/admin/update/check
```
Risposta: `{ ok, versions: {...} }` oppure errore.

### 4. Applicare l'aggiornamento
Invia:
```
curl -X POST -H "Content-Type: application/json" -H "X-API-KEY: ${API_KEY}" \
  -d '{"version":"2025.09.03-170000", "url":"https://host/bundles/bundle_v2025.09.03-170000_0123...ff.zip", "sha256":"0123...ff"}' \
  http://<host>:8081/admin/update/apply
```
Note:
- `sha256` è consigliato. Se omesso ma l'URL contiene `_64hex.zip`, l'hash viene estratto automaticamente.
- `service` (solo Linux) può forzare restart di una unit systemd diversa da default.
- `retries` controlla i tentativi di download.

### 5. Monitorare lo stato
```
curl -H "X-API-KEY: ${API_KEY}" http://<host>:8081/admin/update/status
```
Possibili fasi (`phase`):
`idle, init, downloading, verifying, extracting, installing, ok, warning, error`.

### 6. Rollback (se necessario)
```
curl -X POST -H "X-API-KEY: ${API_KEY}" http://<host>:8081/admin/update/rollback
```
Tenta di passare alla release precedente presente in `releases/` (directory `v<version>`). Se symlink fallisce (es. Windows) fa copia della cartella.

### Cosa succede internamente durante apply()
1. `init`: imposta stato iniziale.
2. `downloading`: scarica zip (con retry/backoff semplice). Se fornito hash atteso lo verifica subito (mismatch => error).
3. `verifying`: verifica finale hash zip (se disponibile atteso).
4. `extracting`: estrae in `releases/v<version>.tmp/`.
5. Flattens: se dentro c'è una sola cartella annidata, ne sposta il contenuto a livello radice.
6. Legge `manifest.txt` per recuperare `manifest_sha256` (hash contenuti originari).
7. `installing`: rinomina `v<version>.tmp` -> `v<version>`.
8. Switch `current` (symlink atomico; fallback copia su Windows o se symlink fallisce).
9. (Solo Linux) prova `systemctl restart <service>` se definito.
10. `ok` (oppure `warning` se restart fallisce). Ritorna JSON con `zip_sha256` e `manifest_sha256`.

### Differenza hash
- `zip_sha256`: integrità dell'archivio finale distribuito.
- `manifest_sha256`: integrità logica dei contenuti (prima che il manifest includa l'hash stesso).

### Errori tipici
- `download_failed / sha256_mismatch`: controllare URL o corruzione download.
- `switch_failed`: permessi su filesystem; verificare se il processo ha diritti di creare symlink o scrivere.
- `no_prev` (rollback): non esiste release precedente.

### Consigli operativi
- Conservare almeno 2 versioni per rollback sicuro.
- Usare sempre HTTPS + API key.
- Versionare il file `VERSION` per rilasci riproducibili; commit + tag coerenti.
- Automatizzare pubblicazione: dopo `make_bundle.py` caricare zip e rigenerare `versions.json`.

### Minimal automation pseudo-script
```bash
python make_bundle.py
ZIP=$(ls morocco_player/releases/bundle_v* | sort | tail -n1)
SHA=$(echo "$ZIP" | sed -E 's/.*_([0-9a-f]{64})\.zip/\1/')
VERSION=$(echo "$ZIP" | sed -E 's/.*bundle_v([^_]+)_.*/\1/')
# upload $ZIP -> https://host/bundles/
# aggiorna versions.json
curl -X POST -H "Content-Type: application/json" -H "X-API-KEY: $API_KEY" \
  -d "{\"version\":\"$VERSION\",\"url\":\"https://host/bundles/$(basename $ZIP)\",\"sha256\":\"$SHA\"}" \
  http://<host>:8081/admin/update/apply
```

---
Aggiornato allineando README a codice corrente (metodo check(), path bundle, directory release `v<version>`, doppio hash).