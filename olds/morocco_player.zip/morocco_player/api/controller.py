"""Compat wrapper: PlayerController ora reindirizza al backend Qt.
Import di questo modulo mantiene retrocompatibilità col nome originale."""

from api.controller_qt import QtPlayerController as PlayerController  # type: ignore

