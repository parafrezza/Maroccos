#!/usr/bin/env python3
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile, zipfile, time, collections
from pathlib import Path
from urllib.request import urlopen
from typing import Optional

# Platform-aware defaults ampliati per Windows/macOS/Linux
# Linux: /opt (se permesso) altrimenti fallback in ~/.local/share
# macOS: ~/Library/Application Support/vlc_remote
# Windows: %APPDATA%/vlc_remote
if sys.platform == "darwin":
    BASE = Path.home() / "Library" / "Application Support" / "vlc_remote"
    SERVICE = None
elif os.name == "nt":
    BASE = Path(os.environ.get("APPDATA", str(Path.home()))) / "vlc_remote"
    SERVICE = None  # niente systemd su Windows
else:
    BASE = Path("/opt/morocco-player")
    SERVICE = "morocco-player.service"  # nome unit systemd

RELEASES = BASE / "releases"
CURRENT = BASE / "current"


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class UpdateManager:
    """Gestisce lo stato dell'aggiornamento e fornisce API-friendly methods.

    This class wraps the original updater script logic and keeps an in-memory
    status so the server can report progress. It's intentionally simple and
    filesystem-based to avoid dependencies.
    """
    def __init__(self, base: Optional[Path] = None, service: str = SERVICE):
        self.base = Path(base) if base else BASE
        self.releases = self.base / "releases"
        self.current = self.base / "current"
        self.service = service
        # status esteso: phase, message, version, progress (0-100 int)
        self.status = {"phase": "idle", "message": None, "version": None, "progress": 0}
        # log circolare in memoria (dimensione MVP 2000 righe)
        self._log = collections.deque(maxlen=2000)
        self._log_index = 0
        # Creazione directory con fallback permessi
        try:
            self.releases.mkdir(parents=True, exist_ok=True)
        except PermissionError:
            # fallback utente locale (solo Linux tipicamente)
            fallback = Path.home() / ".local" / "share" / "vlc_remote"
            self.base = fallback
            self.releases = self.base / "releases"
            self.current = self.base / "current"
            self.releases.mkdir(parents=True, exist_ok=True)

    def _log_line(self, text: str):
        ts = time.strftime('%H:%M:%S')
        line = f"{ts} {text}"
        self._log.append({"i": self._log_index, "t": line})
        self._log_index += 1
        # stampa anche su stdout per journald
        print(line)

    def log_get(self, since: int = 0, limit: int = 500):
        # restituisce righe con indice >= since
        lines = [l for l in self._log if l["i"] >= since]
        if len(lines) > limit:
            lines = lines[:limit]
        next_idx = lines[-1]["i"] + 1 if lines else since
        done = self.status.get("phase") in ("ok", "error", "warning")
        return {"ok": True, "lines": lines, "next": next_idx, "done": done}

    def _download(self, url: str, dest: Path):
        with urlopen(url) as r, open(dest, "wb") as f:
            total = int(r.headers.get('Content-Length') or 0)
            read = 0
            chunk_size = 1024 * 64
            last_log = 0
            start = time.time()
            while True:
                chunk = r.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                read += len(chunk)
                if total:
                    frac = read / total
                    # progress map: downloading 0-70
                    prog = int(frac * 70)
                    now = time.time()
                    if (prog != self.status.get("progress")) or (now - last_log > 1.0):
                        self._set_status("downloading", message=f"{read/1024/1024:.1f}MB/{total/1024/1024:.1f}MB", progress=prog)
                        self._log_line(f"[downloading] {read}/{total} bytes ({prog}%)")
                        last_log = now
            # assicura step a 70 se completato in 1 chunk (file molto piccolo)
            if self.status.get("progress",0) < 70:
                self._set_status("downloading", message="download complete", progress=70)
            self._log_line(f"Download completato ({read} bytes)")

    def _download_with_retry(self, url: str, dest: Path, expected_sha: Optional[str], attempts: int = 3):
        last_err = None
        for attempt in range(1, attempts+1):
            try:
                if dest.exists():
                    dest.unlink()
                # reset progress a inizio tentativo
                self._set_status("downloading", message=f"download attempt {attempt}/{attempts}", progress=0)
                self._download(url, dest)
                zsha = sha256_of(dest)
                if expected_sha and zsha.lower() != expected_sha.lower():
                    last_err = f"sha256 mismatch (got {zsha} expected {expected_sha})"
                    continue
                return True, zsha
            except Exception as e:
                last_err = str(e)
        return False, last_err

    def status_get(self):
        return {"ok": True, "status": self.status}

    def _set_status(self, phase, message=None, version=None, progress: int | None = None):
        if progress is not None:
            self.status["progress"] = max(0, min(100, int(progress)))
        self.status.update({"phase": phase, "message": message, "version": version})
        if message:
            self._log_line(f"[{phase}] {message}")

    def check(self, versions_url: str, timeout: int = 10):
        """Recupera la lista versioni remota (versions.json) e la ritorna.
        Non modifica lo stato di installazione ma aggiorna temporaneamente la phase a 'checking'.
        Ritorna: { ok: bool, versions: <json> } oppure { ok: False, error: str }.
        """
        import json, urllib.request
        prev = dict(self.status)
        try:
            self._set_status("checking", message=f"fetch {versions_url}")
            req = urllib.request.Request(versions_url, headers={"User-Agent": "UpdateManager/1"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            try:
                parsed = json.loads(data.decode('utf-8'))
            except Exception as e:  # json decode
                self._set_status("idle", message="check failed json decode")
                return {"ok": False, "error": f"json_decode: {e}"}
            self._set_status(prev.get("phase", "idle"), message=prev.get("message"), version=prev.get("version"))
            return {"ok": True, "versions": parsed}
        except Exception as e:
            self._set_status(prev.get("phase", "idle"), message=prev.get("message"), version=prev.get("version"))
            return {"ok": False, "error": str(e)}

    def _extract_expected_hash(self, url: str) -> Optional[str]:
        """Estrae l'hash dal nome file: bundle_v<ver>_<sha256>.zip"""
        print(f"Extracting expected hash from URL: {url}")
        fn = url.split("/")[-1]
        m = re.match(r"bundle_v[0-9A-Za-z_.-]+_([0-9a-fA-F]{64})\.zip$", fn)
        if m:
            h = m.group(1).lower()
            print(f"Extracted expected hash: {h}")
            return h
        return None

    def _switch_current(self, dest: Path) -> bool:
        """Prova switch atomico usando symlink. Su Windows se fallisce copia la cartella.
        Ritorna True se successo."""
        try:
            print(f"Switching current to {dest}")
            tmp_link = self.current.parent / "current_tmp"
            if tmp_link.exists() or tmp_link.is_symlink():
                if tmp_link.is_dir() and not tmp_link.is_symlink():
                    shutil.rmtree(tmp_link, ignore_errors=True)
                else:
                    tmp_link.unlink(missing_ok=True)
            tmp_link.symlink_to(dest)
            os.replace(tmp_link, self.current)
            return True
        except Exception:
            # fallback: copia (meno efficiente ma cross-platform)
            print("Symlink failed, falling back to copy")
            try:
                if self.current.exists() or self.current.is_symlink():
                    if self.current.is_dir() and not self.current.is_symlink():
                        shutil.rmtree(self.current, ignore_errors=True)
                    else:
                        self.current.unlink(missing_ok=True)
                shutil.copytree(dest, self.current)
                return True
            except Exception as e2:
                self._set_status("error", message=f"switch_current failed: {e2}")
                return False

    def apply(self, version: str, url: str, sha256: Optional[str] = None, service: Optional[str] = None, retries: int = 3):
        service = service or self.service
        # expected zip hash: param > extracted from filename
        expected_zip_hash = sha256 or self._extract_expected_hash(url)
        if sha256 is None and expected_zip_hash:
            sha256 = expected_zip_hash
            
        self._set_status("init", message="starting", version=version, progress=0)
        print(f"Applying update to version {version} from {url} (expected sha256: {sha256})")
        tmp = Path(tempfile.mkdtemp())
        try:
            zip_path = tmp / "bundle.zip"
            ok, res = self._download_with_retry(url, zip_path, expected_zip_hash, attempts=retries)
            if not ok:
                self._set_status("error", message=str(res))
                return {"ok": False, "error": "download_failed", "detail": res}
            zip_hash = res if expected_zip_hash else sha256_of(zip_path)
            self._set_status("verifying", message="zip sha256", progress=70)
            if expected_zip_hash and zip_hash.lower() != expected_zip_hash.lower():
                self._set_status("error", message="sha256 mismatch after retries")
                return {"ok": False, "error": "sha256_mismatch", "got": zip_hash, "expected": expected_zip_hash}
            self._set_status("extracting", message="extracting archive", progress=72)
            self._log_line("Inizio estrazione archivio")
            dest_tmp = self.releases / f"v{version}.tmp"    
            if dest_tmp.exists():
                shutil.rmtree(dest_tmp)
            dest_tmp.mkdir(parents=True)
            with zipfile.ZipFile(zip_path, "r") as z:
                members = z.infolist()
                total_files = len(members) or 1
                for idx, info in enumerate(members, 1):
                    z.extract(info, dest_tmp)
                    # extraction progress 72-88
                    frac = idx / total_files
                    prog = 72 + int(frac * 16)
                    if prog > self.status.get("progress", 0):
                        self._set_status("extracting", message=f"{idx}/{total_files} files", version=version, progress=prog)
                        if idx == 1 or idx == total_files or (idx % 25 == 0):
                            self._log_line(f"[extracting] {idx}/{total_files}")

            # se l'archivio ha un'unica cartella annidata, piatta
            entries = list(dest_tmp.iterdir())
            if len(entries) == 1 and entries[0].is_dir():
                inner = entries[0]
                for p in inner.iterdir():
                    shutil.move(str(p), str(dest_tmp))
                shutil.rmtree(inner)

            # leggi manifest per ottenere content hash (non coincide col zip hash finale)
            manifest_hash = None
            man_file = dest_tmp / "manifest.txt"
            if man_file.exists():
                try:
                    for line in man_file.read_text(encoding="utf-8").splitlines():
                        if line.startswith("sha256="):
                            manifest_hash = line.split("=",1)[1].strip()
                            break
                except Exception:
                    pass

            self._set_status("installing", message="promote release", progress=90)
            dest = self.releases / f"v{version}"
            if dest.exists():
                shutil.rmtree(dest)
            dest_tmp.rename(dest)

            if not self._switch_current(dest):
                return {"ok": False, "error": "switch_failed"}

            # restart service se systemd disponibile (solo Linux tipicamente)
            try:
                if (os.name != "nt") and (sys.platform != "darwin"):
                    if service:
                        subprocess.check_call(["systemctl", "restart", service])
            except Exception as e:
                self._set_status("warning", message=f"restart failed: {e}")

            self._set_status("ok", message="updated", version=version, progress=100)
            return {"ok": True, "version": version, "zip_sha256": zip_hash, "manifest_sha256": manifest_hash}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def rollback(self):
        # simple rollback: find previous release and switch
        releases = sorted([p for p in self.releases.iterdir() if p.is_dir() and p.name.startswith("v")])
        if not releases:
            return {"ok": False, "error": "no_releases"}
        current_target = None
        try:
            if self.current.is_symlink():
                current_target = Path(os.readlink(self.current))
        except Exception:
            current_target = None
        # pick previous
        prev = None
        for i in range(len(releases)-1, -1, -1):
            if current_target and releases[i] == current_target:
                if i-1 >= 0:
                    prev = releases[i-1]
                break
        if prev is None and len(releases) >= 2:
            prev = releases[-2]
        if prev is None:
            return {"ok": False, "error": "no_prev"}

        if not self._switch_current(prev):
            return {"ok": False, "error": "switch_failed"}
        try:
            if (os.name != "nt") and (sys.platform != "darwin") and self.service:
                subprocess.check_call(["systemctl", "restart", self.service])
        except Exception:
            pass
        return {"ok": True, "rolled_to": prev.name}


def main_cli():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", required=True)
    ap.add_argument("--url", required=True)
    ap.add_argument("--sha256", help="hash atteso (se omesso, estratto dal nome file se presente)")
    ap.add_argument("--service", default=SERVICE)
    ap.add_argument("--retries", type=int, default=3)
    args = ap.parse_args()
    um = UpdateManager()
    r = um.apply(args.version, args.url, sha256=args.sha256, service=args.service, retries=args.retries)
    if not r.get("ok"):
        print("ERROR", r)
        sys.exit(2)
    print("OK: aggiornato a", args.version, "zip_sha256=", r.get("zip_sha256"), "manifest_sha256=", r.get("manifest_sha256"))

if __name__ == "__main__":
    main_cli()