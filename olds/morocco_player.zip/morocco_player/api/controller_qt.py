#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Qt based experimental player controller.

Provides a subset of the VLC PlayerController API so existing command mappings
continue to function. Uses PyQt6 (preferred) or falls back to PyQt5 if available.

Implemented features:
- load / play / pause / stop
- basic fade (black overlay opacity animation)
- black (instant or fade) using same overlay
- status reporting compatible keys: ok, state, time_ms, length_ms (length if known), brightness/contrast placeholders
- take (simplified crossfade: fade out, load, fade in)

Limitations:
- Contrast/Saturation not directly manipulated (Qt Multimedia does not expose easily); values are simulated.
- Looping / playlist / preload / download features not implemented here (stubs provided to avoid command errors).

Threading model:
- A background Qt thread hosts the QApplication and the video widget.
- Public methods marshal GUI operations into the Qt event loop via invokeMethod.

This is intentionally minimal and experimental; not production ready.
"""
from __future__ import annotations
import os, threading, time, socket
from typing import Optional, List

# Try PyQt6 then PyQt5; allow running without QtMultimedia (headless stub)
QT_MAJOR = 0
QtCore = QtWidgets = QtMultimedia = QtMultimediaWidgets = None  # type: ignore
_NO_MULTIMEDIA = False
try:
    from PyQt6 import QtCore, QtWidgets, QtMultimedia, QtMultimediaWidgets  # type: ignore
    QT_MAJOR = 6
except Exception:
    try:
        from PyQt5 import QtCore, QtWidgets  # type: ignore
        QT_MAJOR = 5
        # QtMultimedia separate su alcune build Raspberry: prova import parziale
        try:
            from PyQt5 import QtMultimedia, QtMultimediaWidgets  # type: ignore
        except Exception:
            QtMultimedia = None  # type: ignore
            QtMultimediaWidgets = None  # type: ignore
            _NO_MULTIMEDIA = True
    except Exception as e:
        raise ImportError("PyQt5/6 QtCore+QtWidgets richiesti: " + str(e))


class _VideoWindow(QtWidgets.QWidget):
    faded = None  # signal placeholder for PyQt5/6 compatibility without explicit pyqtSignal usage here

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Morocco Player (Qt)")
        self.resize(1280, 720)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DontCreateNativeAncestors)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_NativeWindow)

        layout = QtWidgets.QStackedLayout(self)
        if not _NO_MULTIMEDIA and QtMultimediaWidgets is not None:
            self.video_widget = QtMultimediaWidgets.QVideoWidget(self)  # type: ignore
        else:
            # Placeholder widget (no video backend available)
            self.video_widget = QtWidgets.QLabel("(Video non disponibile: QtMultimedia mancante)", self)
            self.video_widget.setStyleSheet("color: white; background-color: #202020; padding:12px;")
        layout.addWidget(self.video_widget)

        # Overlay for fades / black
        self.overlay = QtWidgets.QWidget(self)
        self.overlay.setStyleSheet("background-color: black;")
        self.overlay.setAutoFillBackground(True)
        self.overlay.show()
        self.overlay.raise_()
        layout.addWidget(self.overlay)

        self.effect = QtWidgets.QGraphicsOpacityEffect(self.overlay)
        self.overlay.setGraphicsEffect(self.effect)
        self.effect.setOpacity(1.0)
        self.anim = QtCore.QPropertyAnimation(self.effect, b"opacity", self)
        self.anim.setStartValue(1.0)
        self.anim.setEndValue(0.0)
        self.anim.setDuration(0)

    def fade(self, to_black: bool, dur_ms: int):
        self.anim.stop()
        start = self.effect.opacity()
        end = 1.0 if to_black else 0.0
        if dur_ms <= 0:
            self.effect.setOpacity(end)
            return
        self.anim.setDuration(dur_ms)
        self.anim.setStartValue(start)
        self.anim.setEndValue(end)
        self.anim.start()


class QtPlayerController:
    def __init__(self, version_text: str | None = None, show_info: bool = True):
        self._app_thread = None
        self._app = None
        self._win = None
        self._player = None
        self._media_path = None
        self._lock = threading.RLock()
        self._last_state = 'stopped'
        self.media_root = os.path.abspath('media')
        os.makedirs(self.media_root, exist_ok=True)
        # Playlist state
        self._playlist: list[str] = []
        self._playlist_index = -1
        self._playlist_loop = False
        self._loop_one: str | None = None
        self._preloaded: str | None = None
        self._version_text = version_text
        self._show_info = show_info
        self._start_qt_thread()

    # Qt thread bootstrap
    def _start_qt_thread(self):
        ev = threading.Event()

        def _run():
            self._app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(['morocco-qt'])
            # QMediaPlayer API changed slightly between Qt5/6 but this works for both basic use
            self._player = None
            self._win = _VideoWindow()
            try:
                print(f"[QT] Avvio finestra - QtMajor={QT_MAJOR} _NO_MULTIMEDIA={_NO_MULTIMEDIA}")
            except Exception:
                pass
            # Assicura schermo iniziale nero
            try:
                if self._win and hasattr(self._win, 'effect'):
                    self._win.effect.setOpacity(1.0)
            except Exception:
                pass
            if not _NO_MULTIMEDIA and QtMultimedia is not None:
                try:
                    self._player = QtMultimedia.QMediaPlayer()  # type: ignore
                    # setVideoOutput solo se widget reale
                    if hasattr(self._win.video_widget, 'winId'):
                        try:
                            self._player.setVideoOutput(self._win.video_widget)  # type: ignore[attr-defined]
                        except Exception:
                            pass
                except Exception:
                    self._player = None
                    # Imposta flag globale senza ridefinire dopo uso
                    try:
                        globals()['_NO_MULTIMEDIA'] = True
                    except Exception:
                        pass
            self._win.show()
            try:
                self._win.showFullScreen()
            except Exception:
                pass
            # Info overlay (IP, versione, orario) aggiornato ogni 5s
            if self._show_info:
                try:
                    lbl = QtWidgets.QLabel(self._win)
                    lbl.setObjectName("infoLabel")
                    lbl.setStyleSheet("QLabel { color: white; background-color: rgba(0,0,0,160); padding:6px; font: 13px 'Monospace'; border-radius:4px; }")
                    lbl.move(8,8)
                    lbl.setAttribute(QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents)
                    def _tick():
                        ip = self._get_local_ip()
                        parts = [f"IP: {ip}"]
                        if self._version_text:
                            parts.append(self._version_text)
                        parts.append(time.strftime('%H:%M:%S'))
                        lbl.setText(" | ".join(parts))
                        lbl.adjustSize()
                    _tick()
                    timer = QtCore.QTimer(lbl)
                    timer.timeout.connect(_tick)  # type: ignore[attr-defined]
                    timer.start(5000)
                except Exception:
                    pass
            ev.set()
            self._app.exec()

        self._app_thread = threading.Thread(target=_run, daemon=True)
        self._app_thread.start()
        ev.wait(5.0)

    # Utility path helpers
    def _is_url(self, s: str):
        return s.startswith('http://') or s.startswith('https://') or s.startswith('rtsp://')

    def _normalize_input(self, src: str | None):
        if not src:
            return None
        if self._is_url(src) or os.path.isabs(src):
            return src
        p = os.path.normpath(src)
        if p.startswith('..'):
            p = os.path.basename(p)
        return os.path.join(self.media_root, p)

    # Public API (subset mirroring VLC controller)
    def load(self, input: str):
        path = self._normalize_input(input)
        if not path:
            return {'ok': False, 'error': 'invalid'}
        # Non toccare loop_one qui: gestito esplicitamente via loop_one()
        self._media_path = path

        def _do():
            if self._player is None:
                return
            if self._is_url(path):
                if not _NO_MULTIMEDIA and self._player:
                    try: self._player.setSource(QtCore.QUrl(path))  # type: ignore[attr-defined]
                    except Exception: pass
            else:
                if not _NO_MULTIMEDIA and self._player:
                    try: self._player.setSource(QtCore.QUrl.fromLocalFile(path))  # type: ignore[attr-defined]
                    except Exception: pass

        self._invoke_gui(_do)
        return {'ok': True, 'loaded': path}

    def play(self):
        def _do():
            if self._player:
                try: self._player.play()
                except Exception: pass
            if self._win:
                self._win.fade(False, 0)
            if self._player and not _NO_MULTIMEDIA:
                try:
                    self._player.mediaStatusChanged.disconnect()  # type: ignore[attr-defined]
                except Exception:
                    pass
                try:
                    self._player.mediaStatusChanged.connect(self._on_media_status)  # type: ignore[attr-defined]
                except Exception:
                    pass

        self._invoke_gui(_do)
        self._last_state = 'playing'
        return {'ok': True}

    def pause(self):
        def _do():
            if self._player:
                self._player.pause()

        self._invoke_gui(_do)
        self._last_state = 'paused'
        return {'ok': True}

    def stop(self):
        def _do():
            if self._player:
                try: self._player.stop()
                except Exception: pass
                if not _NO_MULTIMEDIA:
                    try: self._player.mediaStatusChanged.disconnect()  # type: ignore[attr-defined]
                    except Exception: pass

        self._invoke_gui(_do)
        self._last_state = 'stopped'
        return {'ok': True}

    # Fade helpers
    def _fade(self, to_black: bool, dur: float):
        ms = max(0, int(dur * 1000))

        def _do():
            if self._win:
                self._win.fade(to_black, ms)

        self._invoke_gui(_do)
        return {'ok': True, 'to_black': to_black, 'duration': dur}

    def fadeout(self, dur=1.2, fps=60, curve='ease', strict: bool = False):
        return self._fade(True, float(dur))

    def fadein(self, dur=1.2, fps=60, curve='ease', strict: bool = False):
        return self._fade(False, float(dur))

    # Simulated brightness/contrast using overlay opacity inversion logic
    # brightness: 0 (black) -> 1 (normal). We implement by adjusting overlay alpha if not already used for fades.
    def set_brightness(self, value: float):
        v = max(0.0, min(1.0, float(value)))
        def _do():
            if self._win:
                # if currently fully black (fade), keep; else map brightness to inverse overlay opacity (simple hack)
                current = self._win.effect.opacity() if hasattr(self._win, 'effect') else 0.0
                if current not in (0.0, 1.0):
                    # mid-fade: skip manual brightness to avoid conflicts
                    return
                new_opacity = 1.0 - v  # brightness 1 => overlay hidden
                self._win.effect.setOpacity(new_opacity)
        self._invoke_gui(_do)
        return { 'ok': True, 'brightness': v }

    def get_brightness(self):
        val = 1.0
        if self._win and hasattr(self._win, 'effect'):
            try:
                val = 1.0 - float(self._win.effect.opacity())
            except Exception:
                pass
        return { 'ok': True, 'brightness': max(0.0, min(1.0, val)) }

    # Contrast not directly changeable; simulate storing a value
    def set_contrast(self, value: float):
        try:
            self._sim_contrast = max(0.0, min(2.0, float(value)))
        except Exception:
            self._sim_contrast = 1.0
        return { 'ok': True, 'contrast': getattr(self, '_sim_contrast', 1.0) }

    def get_contrast(self):
        return { 'ok': True, 'contrast': getattr(self, '_sim_contrast', 1.0) }

    def black(self, dur: float = 0.0, fps: int = 60, curve: str = 'ease', on: bool = True, strict: bool = False):
        if dur and dur > 0:
            return self._fade(on, float(dur)) if on else self._fade(False, float(dur))

        def _do():
            if self._win:
                self._win.effect.setOpacity(1.0 if on else 0.0)

        self._invoke_gui(_do)
        return {'ok': True, 'black': on, 'instant': True}

    def take(self, input: str | None, dur=1.2, dur_out=None, dur_in=None,
             fps=60, curve_out='ease', curve_in='ease', strict: bool = False):
        dur_total = float(dur)
        half = dur_total / 2.0
        out_d = float(dur_out) if dur_out is not None else half
        in_d = float(dur_in) if dur_in is not None else half
        self.fadeout(out_d)
        self.pause()
        loaded = None
        if input:
            r = self.load(input)
            loaded = r.get('loaded') if r.get('ok') else None
        self.play()
        self.black(0.0, on=True)
        self.fadein(in_d)
        return {'ok': True, 'loaded': loaded}

    def status(self):
        # Recupera posizione e durata se possibile
        pos = dur = None
        if self._player and not _NO_MULTIMEDIA:
            try:
                # Qt6: position(), duration(); Qt5 idem
                pos = int(self._player.position())  # type: ignore[attr-defined]
                dur = int(self._player.duration())  # type: ignore[attr-defined]
            except Exception:
                pos = dur = None
        return {
            'ok': True,
            'state': self._last_state,
            'time_ms': pos,
            'length_ms': dur,
            'brightness': 1.0,
            'contrast': 1.0,
            'preloaded': self._preloaded,
            'playlist_count': len(self._playlist),
            'playlist_index': self._playlist_index,
            'playlist_current': self._playlist[self._playlist_index] if 0 <= self._playlist_index < len(self._playlist) else None,
            'playlist_loop': self._playlist_loop,
            'loop_one': self._loop_one,
            'video_disabled': _NO_MULTIMEDIA
        }

    # GUI invoke utility
    def _invoke_gui(self, fn):
        if self._app is None:
            return
        if threading.current_thread() is self._app_thread:
            fn(); return
        # Use singleShot to ensure lambda executed in GUI thread
        QtCore.QTimer.singleShot(0, fn)

    # Compatibility stubs
    def fullscreen(self, on: bool = True):
        def _do():
            if self._win:
                if on:
                    self._win.showFullScreen()
                else:
                    self._win.showNormal()

        self._invoke_gui(_do)
        return {'ok': True, 'fullscreen': on}

    # Playlist & advanced features (basic implementation)
    def playlist_add(self, input: str):
        p = self._normalize_input(input)
        if not p:
            return {'ok': False, 'error': 'invalid'}
        with self._lock:
            self._playlist.append(p)
        return {'ok': True, 'count': len(self._playlist)}

    def playlist_clear(self):
        with self._lock:
            self._playlist.clear(); self._playlist_index = -1
        return {'ok': True}

    def playlist_play(self):
        with self._lock:
            if not self._playlist:
                return {'ok': False, 'error': 'empty'}
            if self._playlist_index < 0 or self._playlist_index >= len(self._playlist):
                self._playlist_index = 0
            cur = self._playlist[self._playlist_index]
        self.load(cur); self.play()
        return {'ok': True, 'current': cur, 'index': self._playlist_index}

    def playlist_next(self):
        with self._lock:
            if not self._playlist:
                return {'ok': False, 'error': 'empty'}
            if self._loop_one:
                target = self._loop_one
            else:
                self._playlist_index += 1
                if self._playlist_index >= len(self._playlist):
                    if self._playlist_loop:
                        self._playlist_index = 0
                    else:
                        self._playlist_index = len(self._playlist)-1
                        return {'ok': False, 'eof': True}
                target = self._playlist[self._playlist_index]
        self.load(target); self.play()
        return {'ok': True, 'current': target, 'index': self._playlist_index, 'loop_one': bool(self._loop_one)}

    def playlist_prev(self):
        with self._lock:
            if not self._playlist:
                return {'ok': False, 'error': 'empty'}
            self._playlist_index -= 1
            if self._playlist_index < 0:
                if self._playlist_loop:
                    self._playlist_index = len(self._playlist)-1
                else:
                    self._playlist_index = 0
            target = self._playlist[self._playlist_index]
        self.load(target); self.play()
        return {'ok': True, 'current': target, 'index': self._playlist_index}

    def playlist_loop(self, on: bool):
        with self._lock:
            self._playlist_loop = bool(on)
        return {'ok': True, 'loop': self._playlist_loop}

    def playlist_status(self):
        with self._lock:
            cur = self._playlist[self._playlist_index] if 0 <= self._playlist_index < len(self._playlist) else None
            return {'ok': True, 'count': len(self._playlist), 'index': self._playlist_index, 'current': cur, 'loop': self._playlist_loop, 'loop_one': self._loop_one}

    def playlist_add_all_media(self):
        added = 0
        try:
            for name in sorted(os.listdir(self.media_root)):
                if name.lower().endswith(('.mp4','.mov','.mkv','.avi','.mpg','.mpeg')):
                    full = os.path.join(self.media_root, name)
                    with self._lock:
                        self._playlist.append(full)
                    added += 1
        except Exception:
            pass
        return {'ok': True, 'added': added, 'count': len(self._playlist)}

    def get_ready(self):
        return {'ok': True, 'preloaded': self._preloaded, 'playlist_count': len(self._playlist)}

    def loop_one(self, input: str | None = None, on: bool = True):
        with self._lock:
            if not on:
                self._loop_one = None
            else:
                if input:
                    p = self._normalize_input(input)
                    if p:
                        self._loop_one = p
                if not self._loop_one and 0 <= self._playlist_index < len(self._playlist):
                    self._loop_one = self._playlist[self._playlist_index]
        return {'ok': True, 'loop_one': self._loop_one}

    def preload(self, input: str):
        p = self._normalize_input(input)
        if not p:
            return {'ok': False, 'error': 'invalid'}
        self._preloaded = p
        return {'ok': True, 'preloaded': p}

    def preload_clear(self):
        self._preloaded = None
        return {'ok': True}

    def take_preloaded(self, *a, **kw):
        if not self._preloaded:
            return {'ok': False, 'error': 'no_preloaded'}
        self.load(self._preloaded); self.play()
        return {'ok': True, 'taken': self._preloaded}
    # Download di un singolo file (HTTP/HTTPS). Ritorna info sul file locale salvato.
    def download(self, path: str):
        if not path or not (path.startswith('http://') or path.startswith('https://')):
            return {'ok': False, 'error': 'unsupported_or_empty'}
        import hashlib, requests
        try:
            resp = requests.get(path, stream=True, timeout=15)
            if resp.status_code != 200:
                return {'ok': False, 'error': f'status_{resp.status_code}'}
            # determina nome file
            name = os.path.basename(path.split('?')[0]) or 'download.bin'
            if '.' not in name:
                # tenta estensione da content-type
                ct = resp.headers.get('Content-Type','')
                if 'mp4' in ct: name += '.mp4'
                elif 'mpeg' in ct: name += '.mpeg'
                elif 'quicktime' in ct: name += '.mov'
            out_path = os.path.join(self.media_root, name)
            h = hashlib.sha256()
            size = 0
            with open(out_path, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if not chunk: continue
                    f.write(chunk)
                    h.update(chunk)
                    size += len(chunk)
            if size == 0:
                try: os.remove(out_path)
                except Exception: pass
                return {'ok': False, 'error': 'empty_file'}
            info = {'ok': True, 'file': name, 'size': size, 'sha256': h.hexdigest()}
            return info
        except Exception as e:
            return {'ok': False, 'error': str(e)}

    # Scarica più media: accetta
    # - remote_dir che termina con .json -> lista JSON di URL
    # - remote_dir URL di base + manifest semplice (text) contenente URL (uno per riga)
    def download_media(self, remote_dir: str):
        if not remote_dir:
            return {'ok': False, 'error': 'empty'}
        import requests, json
        urls: list[str] = []
        try:
            r = requests.get(remote_dir, timeout=15)
            if r.status_code != 200:
                return {'ok': False, 'error': f'status_{r.status_code}'}
            text = r.text.strip()
            if remote_dir.lower().endswith('.json'):
                try:
                    data = json.loads(text)
                    if isinstance(data, list):
                        urls = [u for u in data if isinstance(u, str)]
                except Exception as e:
                    return {'ok': False, 'error': f'invalid_json:{e}'}
            else:
                # parse line list manifest
                for ln in text.splitlines():
                    ln = ln.strip()
                    if not ln or ln.startswith('#'): continue
                    if ln.startswith('http://') or ln.startswith('https://'):
                        urls.append(ln)
            results = []
            for u in urls:
                res = self.download(u)
                results.append({'url': u, **res})
            ok_count = sum(1 for r in results if r.get('ok'))
            return {'ok': True, 'count': len(results), 'downloaded': ok_count, 'items': results}
        except Exception as e:
            return {'ok': False, 'error': str(e)}

    # Internal helpers
    def _on_media_status(self, status):
        if _NO_MULTIMEDIA:
            return
        try: name = str(status)
        except Exception: name = ''
        if 'EndOfMedia' in name:
            if self._loop_one:
                self.load(self._loop_one); self.play()
            else:
                self.playlist_next()

    def _get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.2)
            s.connect(('1.1.1.1', 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return '0.0.0.0'
