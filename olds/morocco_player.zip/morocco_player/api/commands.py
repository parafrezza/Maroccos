#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .controller import PlayerController

def build_commands(ctrl: PlayerController):
    return {
        "load":       lambda p: ctrl.load(p.get("input","")),
        "play":       lambda p: ctrl.play(),
        "pause":      lambda p: ctrl.pause(),
        "stop":       lambda p: ctrl.stop(),
        "fadeout":    lambda p: ctrl.fadeout(float(p.get("dur",1.2)), int(p.get("fps",60)), p.get("curve","ease"), bool(int(p.get("strict",0)))),
        "fadein":     lambda p: ctrl.fadein(float(p.get("dur",1.2)), int(p.get("fps",60)), p.get("curve","ease"), bool(int(p.get("strict",0)))),
        "take":       lambda p: ctrl.take(p.get("input"), float(p.get("dur",1.2)),
                                          p.get("dur_out"), p.get("dur_in"),
                                          int(p.get("fps",60)), p.get("curve_out","ease"), p.get("curve_in","ease"), bool(int(p.get("strict",0)))),
        "preload":    lambda p: ctrl.preload(p.get("input","")),
        "preload_clear": lambda p: ctrl.preload_clear(),
        "take_preloaded": lambda p: ctrl.take_preloaded(float(p.get("dur",1.2))),
        "status":     lambda p: ctrl.status(),
        "playlist_add": lambda p: ctrl.playlist_add(p.get("input","")),
        "playlist_clear": lambda p: ctrl.playlist_clear(),
        "playlist_play": lambda p: ctrl.playlist_play(),
        "playlist_next": lambda p: ctrl.playlist_next(),
        "playlist_prev": lambda p: ctrl.playlist_prev(),
        "playlist_loop": lambda p: ctrl.playlist_loop(p.get("on","1") in ("1","true","yes")),
        "playlist_status": lambda p: ctrl.playlist_status(),
        "playlist_add_all_media": lambda p: ctrl.playlist_add_all_media(),
        "download": lambda p: ctrl.download(p.get("path","")),
        "download_media": lambda p: ctrl.download_media(p.get("path","")),
        "black": lambda p: ctrl.black(float(p.get("dur",0.0)), int(p.get("fps",60)), p.get("curve","ease"), on= p.get("on","1") not in ("0","false","off"), strict=bool(int(p.get("strict",0)))),
        "fullscreen": lambda p: ctrl.fullscreen(p.get("on","1") in ("1","true","yes","on")),
    "video/reset": lambda p: ctrl.reset_video(),
    "video/status": lambda p: ctrl.video_status(),
        "get-ready": lambda p: ctrl.get_ready(),
    "loop_one": lambda p: ctrl.loop_one(p.get("input"), p.get("on","1") in ("1","true","yes","on")),
    "health": lambda p: {"ok": True, "video_disabled": getattr(ctrl, '_player', None) is None or getattr(ctrl, 'status')().get('video_disabled'), "state": getattr(ctrl,'_last_state','unknown')},
    "brightness": lambda p: ctrl.set_brightness(float(p.get("value", p.get("v", 1.0)))) if "value" in p or "v" in p else ctrl.get_brightness(),
    "contrast": lambda p: ctrl.set_contrast(float(p.get("value", p.get("v", 1.0)))) if "value" in p or "v" in p else ctrl.get_contrast(),
    }
