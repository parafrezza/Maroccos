#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, time, threading, uuid, os, sys
import signal
import datetime, subprocess
from api.controller_qt import QtPlayerController  # backend unico Qt
from api.commands import build_commands
from protocols.http_server import start_http, set_debug as http_set_debug
from protocols.udp_server import start_udp, set_debug as udp_set_debug, get_debug as udp_get_debug
from protocols.tcp_server import start_tcp, set_debug as tcp_set_debug
from api.updater import UpdateManager
try:
    from protocols.osc_server import start_osc, set_debug as osc_set_debug
except:
    start_osc = None
    def osc_set_debug(flag: bool):
        pass

import zipfile
from pathlib import Path

SETTINGS_DEFAULT = {
    "HOST": "0.0.0.0",
    "HTTP_PORT": "8081",
    "UDP_PORT": "5000",
    "TCP_PORT": "5001",
    "OSC_PORT": "5002",
    "UDP_RESPOND": "1",
    # DEBUG opzionale
}

def load_settings(path: str | None):
    cfg = SETTINGS_DEFAULT.copy()
    if not path:
        path = "settings.txt"
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if not line or line.startswith("#"): continue
                if "=" in line:
                    k,v = line.split("=",1)
                    cfg[k.strip().upper()] = v.strip()
    return cfg


def _watchdog_loop(cmd, status_file, check_interval=5.0):
    """Simple watchdog: if status_file doesn't indicate clean_exit, ensure cmd is running.

    cmd: list of command args to start the main server
    status_file: path to a json file written by the main process with {clean_exit: bool}
    """
    import json as _json, subprocess
    proc = None
    while True:
        try:
            st = None
            if os.path.exists(status_file):
                try:
                    st = _json.load(open(status_file, "r"))
                except Exception:
                    st = None
            # if no file or clean_exit is False -> ensure process running
            need_start = True
            if st and st.get("clean_exit"):
                need_start = False
            if need_start:
                if proc is None or proc.poll() is not None:
                    # start process
                    proc = subprocess.Popen(cmd)
            else:
                # if clean exit reported, stop
                if proc and proc.poll() is None:
                    try: proc.terminate()
                    except Exception: pass
                break
        except Exception:
            pass
        time.sleep(check_interval)


def start_watchdog_if_needed(cfg):
    try:
        prod = cfg.get("PRODUCTION", "0") in ("1", "true", "yes")
    except Exception:
        prod = False
    if not prod:
        return None
    # prepare status file
    status_file = os.path.join(os.getcwd(), ".server_status.json")
    # clear file to force watchdog start
    try:
        import json as _json
        _json.dump({"clean_exit": False, "timestamp": time.time()}, open(status_file, "w"))
    except Exception:
        pass
    # build command to run main in a subprocess (python3 path/to/main.py)
    cmd = [sys.executable, os.path.join(os.getcwd(), os.path.basename(__file__))]
    thr = threading.Thread(target=_watchdog_loop, args=(cmd, status_file), daemon=True)
    thr.start()
    print("[WATCHDOG] Avviato")
    return thr

class Scheduler:
    def __init__(self, commands):
        self._cmds = commands
        self._lock = threading.Lock()
        self._tasks = {}  # id -> dict
        self._ev = threading.Event()
        self._thr = threading.Thread(target=self._loop, daemon=True)
        self._thr.start()

    def schedule(self, cmd, params, delay):
        sid = str(uuid.uuid4())
        run_at = time.time() + delay
        with self._lock:
            # consenti UN SOLO timer: rimuovi pending esistenti
            for tid, t in list(self._tasks.items()):
                if t.get("status") == "pending":
                    self._tasks.pop(tid, None)
            self._tasks[sid] = {"id": sid, "cmd": cmd, "params": params, "run_at": run_at, "created": time.time(), "status": "pending"}
            self._ev.set()
        return sid

    def cancel(self, sid):
        with self._lock:
            return self._tasks.pop(sid, None) is not None

    def list(self):
        with self._lock:
            return list(self._tasks.values())

    def _loop(self):
        while True:
            now = time.time()
            due = []
            with self._lock:
                for sid, t in list(self._tasks.items()):
                    if t["status"] == "pending" and t["run_at"] <= now:
                        due.append((sid,t))
            for sid,t in due:
                fn = self._cmds.get(t["cmd"])
                if fn:
                    try: t["result"] = fn(t["params"])
                    except Exception as e: t["result"] = {"ok": False, "error": str(e)}
                t["status"] = "done"
                with self._lock:
                    t["completed"] = time.time()
                time.sleep(0.001)
            # cleanup vecchi
            with self._lock:
                for sid,t in list(self._tasks.items()):
                    if t.get("status")=="done" and (time.time()-t["completed"])>30:
                        self._tasks.pop(sid, None)
            # attesa
            with self._lock:
                pending = [t for t in self._tasks.values() if t["status"]=="pending"]
                if not pending:
                    self._ev.wait(1.0); self._ev.clear()
                else:
                    next_run = min(t["run_at"] for t in pending)
                    timeout = max(0.05, min(1.0, next_run - time.time()))
                    self._ev.wait(timeout); self._ev.clear()

def _get_version_text() -> str | None:
    """Prova a recuperare una stringa versione da manifest.txt locale o dagli ultimi bundle in releases/.
    Ritorna la prima riga non vuota del manifest se trovata."""
    try:
        # 1) manifest.txt affiancato
        here = Path(__file__).resolve().parent
        mf1 = here / 'manifest.txt'
        if mf1.exists():
            line = next((ln.strip() for ln in mf1.read_text(encoding='utf-8', errors='replace').splitlines() if ln.strip()), None)
            if line:
                return line
        # 2) cerca nel bundle più recente in releases/
        releases = here / 'releases'
        if releases.is_dir():
            zips = sorted(releases.glob('bundle_v*_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
            for zpath in zips:
                try:
                    with zipfile.ZipFile(zpath, 'r') as zf:
                        for name in zf.namelist():
                            if name.endswith('manifest.txt'):
                                data = zf.read(name).decode('utf-8', errors='replace')
                                line = next((ln.strip() for ln in data.splitlines() if ln.strip()), None)
                                if line:
                                    return line
                except Exception:
                    continue
    except Exception:
        pass
    return None

def _generate_linux_info_wallpaper(output_path: str, overlay_size: str | None = None, version_text: str | None = None, rotate: int | None = None):
    """Genera un'immagine nera full-screen con un riquadro testuale in alto a sinistra (default 256x100).
    Mostra: titolo, versione (se disponibile), IPs, timestamp. Richiede Pillow. Ritorna dict con info."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception as e:
        return {"ok": False, "error": f"Pillow not available: {e}"}
    # Recupera IPs (hostname -I)
    try:
        ips_raw = subprocess.check_output(["hostname","-I"], timeout=2).decode().strip()
        ips = [ip for ip in ips_raw.split() if ip.count('.')==3]
    except Exception:
        ips = []
    # Determina risoluzione via Tk (se possibile) altrimenti fallback
    w = h = None
    if sys.platform.startswith("linux"):
        try:
            import tkinter as _tk
            r = _tk.Tk(); r.withdraw(); w=r.winfo_screenwidth(); h=r.winfo_screenheight(); r.destroy()
        except Exception:
            pass
    if not w or not h:
        w, h = 1920, 1080
    img = Image.new("RGB", (w,h), "black")

    # Dimensioni overlay (LxH) in alto-sinistra
    ov_w, ov_h = 256, 100
    if overlay_size:
        try:
            parts = overlay_size.lower().replace(" ", "").replace("+", "x").split("x")
            if len(parts) == 2:
                ow, oh = int(parts[0]), int(parts[1])
                if ow > 10 and oh > 10:
                    ov_w, ov_h = ow, oh
        except Exception:
            pass

    # Font loader da usare dopo per overlay
    def _load_font(px: int):
        try:
            return ImageFont.truetype("DejaVuSansMono.ttf", size=px)
        except Exception:
            return ImageFont.load_default()

    title = "Morocco Player"
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [title]
    if version_text:
        lines.append(f"Version: {version_text}")
    lines.append("IPs: "+ (", ".join(ips) if ips else "(none)"))
    lines.append(f"Started: {now}")

    def _measure(text, font):
        # Pillow >=8.0 prefer textbbox, alcune build rimuovono textsize
        if hasattr(draw, "textbbox"):
            box = draw.textbbox((0,0), text, font=font)
            return box[2]-box[0], box[3]-box[1]
        if hasattr(draw, "textlength"):
            wlen = draw.textlength(text, font=font)
            try:
                ascent, descent = font.getmetrics()
                return int(wlen), ascent+descent
            except Exception:
                return int(wlen), int(h*0.05)
        # fallback finale
        try:
            return draw.textsize(text, font=font)  # type: ignore[attr-defined]
        except Exception:
            return len(text)*10, int(h*0.05)

    # Per mantenere l'overlay in alto-sinistra dopo rotazione, ruota prima l'immagine
    if rotate is None:
        try:
            rot_env = os.environ.get("LINUX_INFO_ROTATE")
            if rot_env is not None:
                rotate = int(rot_env)
        except Exception:
            rotate = None
    if rotate in (90, 180, 270):
        try:
            img = img.rotate(-rotate, expand=True)  # clockwise
        except Exception:
            pass
    # Dopo eventuale rotazione, disegna l'overlay in alto-sinistra
    w, h = img.size
    draw = ImageDraw.Draw(img)
    # Se 90/270, lo spazio overlay desiderato diventa "ruotato" (swap w/h)
    ov_draw_w, ov_draw_h = ov_w, ov_h
    if rotate in (90, 270):
        ov_draw_w, ov_draw_h = ov_h, ov_w
    margin = 8
    avail_w = max(10, ov_draw_w - margin*2)
    avail_h = max(10, ov_draw_h - margin*2)
    size_big = max(10, int(ov_draw_h * 0.34))
    size_small = max(8, int(ov_draw_h * 0.22))
    font_big = _load_font(size_big)
    font_small = _load_font(size_small)
    def _fits(font_b, font_s):
        for i, line in enumerate(lines):
            f = font_b if i == 0 else font_s
            tw, th = _measure(line, f)
            if tw > avail_w:
                return False
        return True
    attempts = 0
    while not _fits(font_big, font_small) and attempts < 10:
        size_big = max(8, int(size_big * 0.9))
        size_small = max(7, int(size_small * 0.9))
        font_big = _load_font(size_big)
        font_small = _load_font(size_small)
        attempts += 1
    y0 = margin
    for i, line in enumerate(lines):
        f = font_big if i == 0 else font_small
        tw, th = _measure(line, f)
        draw.text((margin, y0), line, fill="white", font=f)
        y0 += int(th * 1.2)
    # Rotazione opzionale (es. 90° clockwise per 100x256 visualizzato ruotato)
    # rotazione già applicata prima del disegno overlay
    try:
        img.save(output_path)
        return {"ok": True, "file": output_path, "ips": ips, "size": [w,h], "overlay": [ov_w, ov_h], "version": version_text, "rotated": rotate or 0}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host")
    ap.add_argument("--http", type=int)
    ap.add_argument("--udp", type=int)
    ap.add_argument("--tcp", type=int)
    ap.add_argument("--osc", type=int)
    ap.add_argument("--udp-respond", action="store_true")
    ap.add_argument("--settings", help="path settings.txt", default="settings.txt")
    args = ap.parse_args()

    cfg = load_settings(args.settings)

    # if production mode enabled, start watchdog
    wd = start_watchdog_if_needed(cfg)
    # mark not-clean until shutdown
    try:
        import json as _json
        status_file = os.path.join(os.getcwd(), ".server_status.json")
        _json.dump({"clean_exit": False, "timestamp": time.time()}, open(status_file, "w"))
    except Exception:
        pass

    host = args.host or cfg["HOST"]
    http_port = args.http or int(cfg["HTTP_PORT"])
    udp_port  = args.udp  if args.udp is not None else int(cfg["UDP_PORT"])
    tcp_port  = args.tcp  if args.tcp is not None else int(cfg["TCP_PORT"])
    osc_port  = args.osc  if args.osc is not None else int(cfg["OSC_PORT"])
    udp_respond = args.udp_respond or (cfg.get("UDP_RESPOND","0") in ("1","true","yes"))

    # Debug flag da settings.txt (DEBUG=1/true/yes)
    debug = cfg.get("DEBUG","0").lower() in ("1","true","yes","on")

    # Forza backend Qt (rimosso VLC)
    ver_text = _get_version_text()
    try:
        ctrl = QtPlayerController(version_text=ver_text, show_info=True)
        print("[QT] Backend Qt avviato")
        if ver_text:
            print(f"[VERSION] {ver_text}")
    except Exception as e:
        print(f"[QT][FATAL] Impossibile inizializzare backend Qt: {e}")
        raise SystemExit(2)

    # --- Linux wallpaper informativo ---
    if sys.platform.startswith("linux"):
        try:
            # controlla settings opzionale: LINUX_INFO_WALLPAPER=0 per disabilitare
            if cfg.get("LINUX_INFO_WALLPAPER", "1").lower() in ("1","true","yes","on"):
                wp_path = os.path.abspath("wallpaper_info.png")
                # dimensioni overlay opzionali (es: 256x100)
                overlay_sz = cfg.get("LINUX_INFO_OVERLAY_SIZE", "256x100")
                ver_text = _get_version_text()
                # ruota 90° clockwise per formato 100x256 in alto-sinistra se richiesto da settings
                rotate = None
                rot_cfg = cfg.get("LINUX_INFO_ROTATE")
                if rot_cfg:
                    try: rotate = int(rot_cfg)
                    except Exception: rotate = None
                info = _generate_linux_info_wallpaper(wp_path, overlay_size=overlay_sz, version_text=ver_text, rotate=rotate)
                if info.get("ok"):
                    # prova a impostare come wallpaper (LXDE/pcmanfm)
                    try:
                        subprocess.Popen(["pcmanfm","--set-wallpaper", wp_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    except Exception:
                        pass
                    print(f"[WALLPAPER] generato {wp_path} IPs={info.get('ips')} ver={info.get('version')}")
                else:
                    print(f"[WALLPAPER][ERR] {info.get('error')}")
        except Exception as e:
            print(f"[WALLPAPER][EXC] {e}")

    base_commands = build_commands(ctrl)

    # --- update manager ---
    api_key = cfg.get("API_KEY") or os.environ.get("API_KEY")
    certfile = cfg.get("TLS_CERT")
    keyfile = cfg.get("TLS_KEY")
    update_mgr = UpdateManager()
    restart_after_update = (cfg.get("RESTART_AFTER_UPDATE") or os.environ.get("RESTART_AFTER_UPDATE","0")).lower() in ("1","true","yes","on")

    # wrapper che gestisce 'time'
    scheduler = Scheduler(base_commands)
    def exec_with_time(cmd_name, params):
        delay = 0.0
        if "time" in params:
            try: delay = float(params["time"])
            except: delay = 0.0
            params = {k:v for k,v in params.items() if k!="time"}
        if delay > 0:
            sid = scheduler.schedule(cmd_name, params, delay)
            return {"ok": True, "scheduled": True, "schedule_id": sid, "run_in_sec": delay, "cmd": cmd_name, "params": params}
        return base_commands[cmd_name](params)

    commands = {name: (lambda n: (lambda p: exec_with_time(n,p)))(name) for name in base_commands}

    # comandi scheduler
    commands["schedule_list"] = lambda p: {"ok": True, "schedules": scheduler.list()}
    commands["schedule_cancel"] = lambda p: {"ok": True, "cancelled": scheduler.cancel(p.get("id",""))}

    # --- Admin / Update endpoints ---
    def _get_version(p):
        # read manifest from current (install path) if available
        try:
            cur = update_mgr.current
            mf = cur / "manifest.txt"
            if mf.exists():
                return {"ok": True, "manifest": mf.read_text(encoding="utf-8")}
        except Exception:
            pass
        # fallback: se avviato dal tree sorgente, prova morocco_player/manifest.txt
        try:
            here = Path(__file__).resolve().parent
            mf2 = here / 'manifest.txt'
            if mf2.exists():
                return {"ok": True, "manifest": mf2.read_text(encoding='utf-8'), "source": "local"}
        except Exception:
            pass
        # Fallback 1: cerca nei bundle della dir releases gestita da UpdateManager
        try:
            rel_dir = update_mgr.releases
            if rel_dir.is_dir():
                candidates = sorted(rel_dir.glob('bundle_v*_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
                for zpath in candidates:
                    try:
                        with zipfile.ZipFile(zpath, 'r') as zf:
                            for name in zf.namelist():
                                if name.endswith('manifest.txt'):
                                    data = zf.read(name).decode('utf-8', errors='replace')
                                    return {"ok": True, "manifest": data, "source": "bundle_zip", "bundle": zpath.name}
                    except Exception:
                        continue
        except Exception:
            pass
        # Fallback 2: in ambienti di sviluppo (workspace) cerca in morocco_player/releases accanto al file
        try:
            script_root = Path(__file__).resolve().parent
            releases_dir = script_root / 'releases'
            if releases_dir.is_dir():
                candidates = sorted(releases_dir.glob('bundle_v*_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
                for zpath in candidates:
                    try:
                        with zipfile.ZipFile(zpath, 'r') as zf:
                            for name in zf.namelist():
                                if name.endswith('manifest.txt'):
                                    data = zf.read(name).decode('utf-8', errors='replace')
                                    return {"ok": True, "manifest": data, "source": "bundle_zip", "bundle": zpath.name}
                    except Exception:
                        continue
        except Exception:
            pass
        # fallback finale
        return {"ok": True, "manifest": None}

    def _check_update(p):
        # Usa ora UpdateManager.check per ottenere versions.json
        url = p.get("versions_url")
        if not url:
            return {"ok": False, "error": "missing versions_url"}
        return update_mgr.check(url)

    def _apply_update(p):
        ver = p.get("version")
        url = p.get("url")
        sha = p.get("sha256") or p.get("sha")
        if not (ver and url and sha):
            return {"ok": False, "error": "need version,url,sha256"}
        def worker():
            try:
                update_mgr.apply(ver, url, sha)
                if restart_after_update:
                    print("[UPDATE] Restart dopo update richiesto (RESTART_AFTER_UPDATE=1)", file=sys.stderr)
                    sys.stderr.flush(); sys.stdout.flush()
                    time.sleep(0.5)
                    # Exit code != 0 per innescare Restart=on-failure (systemd)
                    os._exit(1)
            except Exception as e:
                update_mgr._set_status("error", message=str(e))
        import threading
        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True, "started": True, "version": ver, "restart_after_update": restart_after_update}

    def _update_status(p):
        return update_mgr.status_get()

    def _rollback(p):
        return update_mgr.rollback()

    # graceful drain/undrain
    draining = {"state": False}
    def _drain(p):
        # trigger graceful fade and stop
        dur = float(p.get("dur", 1.2))
        try:
            ctrl.fadeout(dur=dur)
        except Exception:
            pass
        try:
            ctrl.stop()
        except Exception:
            pass
        draining["state"] = True
        return {"ok": True, "drained": True}

    def _undrain(p):
        draining["state"] = False
        try:
            ctrl.fadein(dur=float(p.get("dur", 1.0)))
        except Exception:
            pass
        return {"ok": True, "drained": False}

    commands["version"] = lambda p: _get_version(p)
    commands["admin/update/check"] = lambda p: _check_update(p)
    commands["admin/update/apply"] = lambda p: _apply_update(p)
    commands["admin/update/status"] = lambda p: _update_status(p)
    commands["admin/update/log"] = lambda p: update_mgr.log_get(int(p.get("since",0)), int(p.get("limit",500)))
    commands["admin/update/rollback"] = lambda p: _rollback(p)
    commands["admin/drain"] = lambda p: _drain(p)
    commands["admin/undrain"] = lambda p: _undrain(p)

    # --- Wallpaper regenerate (solo Linux) ---
    def _wallpaper_regen(p):
        if not sys.platform.startswith("linux"):
            return {"ok": False, "error": "linux only"}
        wp_path = os.path.abspath("wallpaper_info.png")
        overlay_sz = cfg.get("LINUX_INFO_OVERLAY_SIZE", "256x100")
        ver_text = _get_version_text()
        rotate = None
        rot_cfg = cfg.get("LINUX_INFO_ROTATE")
        if rot_cfg:
            try: rotate = int(rot_cfg)
            except Exception: rotate = None
        info = _generate_linux_info_wallpaper(wp_path, overlay_size=overlay_sz, version_text=ver_text, rotate=rotate)
        if info.get("ok"):
            try:
                subprocess.Popen(["pcmanfm","--set-wallpaper", wp_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass
            return {"ok": True, "regenerated": True, **info}
        return info
    commands["wallpaper/regenerate"] = lambda p: _wallpaper_regen(p)

    # --- Desktop minimale (LXDE) ---
    def _lxde_paths():
        home = Path.home()
        # Raspberry Pi OS di solito usa LXDE-pi
        return {
            "panel": [home/".config"/"lxpanel"/"LXDE-pi"/"panels"/"panel", home/".config"/"lxpanel"/"LXDE"/"panels"/"panel"],
            "pcmanfm": [home/".config"/"pcmanfm"/"LXDE-pi"/"pcmanfm.conf", home/".config"/"pcmanfm"/"LXDE"/"pcmanfm.conf"],
        }

    def _edit_ini(path: Path, section: str, pairs: dict[str,str]):
        try:
            if not path.exists():
                return False
            lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
            out = []
            in_sec = False
            sec_header = f"[{section}]"
            found_sec = False
            written = set()
            for ln in lines:
                stripped = ln.strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    if in_sec:
                        # chiudi sezione: scrivi coppie non viste
                        for k,v in pairs.items():
                            if k not in written:
                                out.append(f"{k}={v}")
                        written = set()
                    in_sec = (stripped == sec_header)
                    if in_sec:
                        found_sec = True
                    out.append(ln)
                    continue
                if in_sec and "=" in ln:
                    k, _ = ln.split("=", 1)
                    k = k.strip()
                    if k in pairs:
                        out.append(f"{k}={pairs[k]}")
                        written.add(k)
                    else:
                        out.append(ln)
                else:
                    out.append(ln)
            if not found_sec:
                out.append(sec_header)
                for k,v in pairs.items():
                    out.append(f"{k}={v}")
            bak = path.with_suffix(path.suffix+".bak")
            # salva backup una sola volta
            try:
                if not bak.exists():
                    bak.write_text("\n".join(lines), encoding='utf-8')
            except Exception:
                pass
            # scrivi output nel file originale
            path.write_text("\n".join(out), encoding='utf-8')
            return True
        except Exception:
            return False

    def _desktop_minimal(p):
        if not sys.platform.startswith("linux"):
            return {"ok": False, "error": "linux only"}
        on = str(p.get("on", "1")).lower() in ("1","true","yes","on")
        paths = _lxde_paths()
        changed = {"panel": False, "pcmanfm": False}
        # lxpanel: autohide
        for panel_path in paths["panel"]:
            if panel_path.exists():
                try:
                    txt = panel_path.read_text(encoding='utf-8', errors='replace')
                    if "autohide=" in txt:
                        txt = re.sub(r"autohide=\d+", f"autohide={'1' if on else '0'}", txt)
                    else:
                        txt += f"\nautohide={'1' if on else '0'}\n"
                    bak = panel_path.with_suffix(panel_path.suffix+".bak")
                    if not bak.exists():
                        panel_path.replace(bak)
                        Path(panel_path).write_text(txt, encoding='utf-8')
                    else:
                        panel_path.write_text(txt, encoding='utf-8')
                    changed["panel"] = True
                except Exception:
                    pass
        # pcmanfm: niente icone sul desktop + modalità wallpaper
        for pc_path in paths["pcmanfm"]:
            ok = _edit_ini(pc_path, "desktop", {
                "show_trash": "0" if on else "1",
                "show_mounts": "0" if on else "1",
                "show_home": "0" if on else "1",
                "show_desktop": "1",  # mantieni gestione desktop per wallpaper
                "wallpaper_mode": "stretch",
            })
            if ok:
                changed["pcmanfm"] = True
        # riavvia componenti LXDE per applicare
        try:
            subprocess.Popen(["lxpanelctl", "restart"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        try:
            subprocess.Popen(["pcmanfm", "--reconfigure"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        return {"ok": True, "minimal": on, "changed": changed}

    import re
    commands["desktop/minimal"] = lambda p: _desktop_minimal(p)

    def _debug_set(flag: bool):
        http_set_debug(flag)
        udp_set_debug(flag)
        tcp_set_debug(flag)
        osc_set_debug(flag)
        return {"ok": True, "debug": flag}

    commands["debug/on"] = lambda p: (_debug_set(True))
    commands["debug/off"] = lambda p: (_debug_set(False))
    commands["debug/status"] = lambda p: {"ok": True, "debug": udp_get_debug()}

    # pass api_key and tls files to HTTP server
    allowlist = None
    if cfg.get("ALLOWLIST"):
        allowlist = [x.strip() for x in cfg.get("ALLOWLIST").split(",") if x.strip()]
    http_srv = start_http(host, http_port, commands, certfile=certfile, keyfile=keyfile, api_key=api_key, allowlist=allowlist)
    http_thread = threading.Thread(target=http_srv.serve_forever, daemon=True)
    http_thread.start()
    print(f"[HTTP] http://{host}:{http_port}/ (thread avviato)")
    if debug: print("[DEBUG] Logging protocollo attivato (settings DEBUG)")

    if udp_port:
        start_udp(host, udp_port, commands, respond=udp_respond, debug=debug)
        print(f"[UDP ] {host}:{udp_port} respond={udp_respond}")

    if tcp_port:
        start_tcp(host, tcp_port, commands, debug=debug)
        print(f"[TCP ] {host}:{tcp_port}")

    if osc_port and start_osc:
        start_osc(host, osc_port, commands)
        print(f"[OSC ] {host}:{osc_port}")
    elif osc_port:
        print("[OSC ] python-osc non installato (non avviato)")

    stop_evt = threading.Event()
    def _handle_stop(sig, frame):
        print(f"\n[MAIN] Segnale ricevuto ({sig}), arresto...")
        stop_evt.set()
    for s in (signal.SIGINT, getattr(signal, "SIGTERM", None)):
        if s:
            try: signal.signal(s, _handle_stop)
            except Exception: pass

    try:
        while not stop_evt.is_set():
            stop_evt.wait(1.0)
    finally:
        print("[MAIN] Shutdown in corso...")
        try:
            http_srv.shutdown()
            http_srv.server_close()
        except Exception:
            pass
        ctrl.stop()
        # mark clean exit
        try:
            status_file = os.path.join(os.getcwd(), ".server_status.json")
            import json as _json
            _json.dump({"clean_exit": True, "timestamp": time.time()}, open(status_file, "w"))
        except Exception:
            pass
        print("[MAIN] Terminato.")

if __name__ == "__main__":
    main()
