#!/usr/bin/env bash
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$APP_DIR/venv"
INSTALL_BASE="/opt/morocco-player"
# TARGET_USER/HOME saranno determinati più sotto (sezione systemd)

# Funzione per i log
log_info() {
  echo "[INFO] $1"
}

log_warn() {
  echo "[WARN] $1"
}

log_error() {
  echo "[ERROR] $1"
}

# Funzione per rilevare se siamo su Raspberry Pi
is_raspberry_pi() {
  if [ -f /proc/device-tree/model ] && grep -q "Raspberry Pi" /proc/device-tree/model; then
    return 0
  fi
  return 1
}

log_info "Inizio setup Morocco Player..."
log_info "Directory applicazione: $APP_DIR"

# Configurazione specifica per Raspberry Pi
if is_raspberry_pi; then
  log_info "Raspberry Pi rilevato - Configurazione display e SSH"
  
  # Configurazione monitor forzato 1280x720
  log_info "Configurazione monitor forzato 1280x720..."
  if [ "$(id -u)" = "0" ]; then
    # Backup del file config originale se non esiste già
    if [ ! -f /boot/config.txt.backup ]; then
      cp /boot/config.txt /boot/config.txt.backup
      log_info "Backup di /boot/config.txt creato"
    fi
    
    # Rimuovi eventuali configurazioni precedenti
    sed -i '/# Morocco Player display config/,/# End Morocco Player display config/d' /boot/config.txt
    
    # Aggiungi nuova configurazione
    cat >> /boot/config.txt <<EOF

# Morocco Player display config
# Forza output HDMI anche senza monitor
hdmi_force_hotplug=1
# Ignora completamente l'EDID del monitor
hdmi_ignore_edid=0xa5000080
# Forza risoluzione 1280x720 @ 60Hz (modalità CEA)
hdmi_group=1
hdmi_mode=4
# Forza output digitale
hdmi_drive=2
# Aumenta il segnale HDMI se necessario
config_hdmi_boost=5
# Disabilita overscan
disable_overscan=1
# Forza la modalità video specifica
hdmi_cvt=1280 720 60 1 0 0 0
hdmi_mode=87
# End Morocco Player display config
EOF
    log_info "Configurazione display applicata (richiede riavvio)"
  else
    log_warn "Permessi root necessari per configurare il display"
  fi
  
  # Attivazione SSH
  log_info "Attivazione servizio SSH..."
  if [ "$(id -u)" = "0" ]; then
    systemctl enable ssh
    systemctl start ssh
    log_info "Servizio SSH attivato"
  else
    log_warn "Permessi root necessari per attivare SSH"
  fi

  # Forza barra LXDE in basso (profilo LXDE-pi)
  log_info "Configurazione barra LXDE in basso (edge=bottom) per l'utente target"
  TARGET_USER="${SUDO_USER:-$(whoami)}"
  TARGET_HOME=$(eval echo "~$TARGET_USER")
  PANEL_FILE="$TARGET_HOME/.config/lxpanel/LXDE-pi/panels/panel"
  if [ -f "$PANEL_FILE" ]; then
    log_info "Modifico $PANEL_FILE (backup .bak)"
    cp -n "$PANEL_FILE" "$PANEL_FILE.bak" 2>/dev/null || true
    awk '
      BEGIN{in_glob=0; seen_edge=0}
      /^[ \t]*Global[ \t]*\{/ { in_glob=1; seen_edge=0; print; next }
      { 
        if(in_glob==1) {
          if($0 ~ /^[ \t]*edge=/){ print "    edge=bottom"; seen_edge=1; next }
          if($0 ~ /^\}/){ if(seen_edge==0){ print "    edge=bottom" } in_glob=0; print; next }
        }
        print
      }
    ' "$PANEL_FILE" > "$PANEL_FILE.tmp" && mv "$PANEL_FILE.tmp" "$PANEL_FILE"
    # Riavvia lxpanel per applicare
    if command -v lxpanelctl >/dev/null 2>&1; then
      lxpanelctl restart || true
    fi
  else
    log_warn "File pannello non trovato: $PANEL_FILE (salto)"
  fi
  
  # Configurazione gruppi utente per VLC e audio/video
  log_info "Configurazione gruppi utente (audio/video se presenti)"
  if [ "$(id -u)" = "0" ]; then
    TARGET_USER="${SUDO_USER:-$(whoami)}"
    for group in audio video render; do
      if getent group "$group" >/dev/null 2>&1; then
        usermod -a -G "$group" "$TARGET_USER" 2>/dev/null || true
      fi
    done
  else
    log_warn "Esegui come root per aggiungere gruppi audio/video"
  fi
else
  log_info "Sistema non Raspberry Pi - salto configurazioni specifiche"
fi

# Setup ambiente Python
log_info "Setup ambiente virtuale Python (Qt only)..."
if ! command -v python3 >/dev/null 2>&1; then
  log_error "python3 non trovato. Installa Python 3 e riprova."
  exit 1
fi
if ! python3 -m venv --help >/dev/null 2>&1; then
  if [ "$(id -u)" = "0" ]; then
    log_info "Installo python3-venv (apt)..."
    apt-get update -qq || true
    apt-get install -y python3-venv || true
  else
    log_error "Modulo venv assente. Esegui: sudo apt-get install -y python3-venv"
    exit 1
  fi
fi
if [ ! -d "$VENV_DIR" ] || [ ! -f "$VENV_DIR/bin/activate" ]; then
  log_info "Creazione (o ricostruzione) venv..."
  rm -rf "$VENV_DIR" 2>/dev/null || true
  # Su Raspberry abilita site-packages globali per usare python3-pyqt5 di sistema
  if is_raspberry_pi; then
    log_info "Raspberry: abilito --system-site-packages per usare PyQt5 di sistema"
    python3 -m venv --system-site-packages "$VENV_DIR"
  else
    python3 -m venv "$VENV_DIR"
  fi
fi
. "$VENV_DIR/bin/activate"
log_info "Aggiorno pip/setuptools/wheel"
python -m pip install --upgrade pip setuptools wheel
log_info "Installo dipendenze applicative"
# Se Raspberry, installa prima PyQt5 via apt per evitare build sorgenti
if is_raspberry_pi; then
  if command -v apt-get >/dev/null 2>&1; then
  log_info "(Raspberry) Installo python3-pyqt5 e moduli multimedia via apt (prima del pip)"
  apt-get update -qq || true
  apt-get install -y python3-pyqt5 python3-pyqt5.qtmultimedia qtbase5-dev \
    gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
    gstreamer1.0-libav || true
  fi
fi
python -m pip install -r "$APP_DIR/requirements.txt"

# Test rapido QtMultimedia (informativo)
python - <<'EOF'
try:
  from PyQt5 import QtMultimedia  # type: ignore
  print('[INFO] QtMultimedia disponibile (PyQt5)')
except Exception as e:
  print('[WARN] QtMultimedia NON disponibile:', e)
EOF

# Test moduli base (PyQt5 obbligatorio)
python - <<'EOF'
import sys
mods = ["requests","PIL","PyQt5"]
missing = []
for m in mods:
  try: __import__(m)
  except ImportError: missing.append(m)
if missing:
  print("[WARN] Moduli mancanti:", ",".join(missing))
EOF

if ! "$VENV_DIR/bin/python" -c 'import PyQt5' 2>/dev/null; then
  log_error "PyQt5 non disponibile dopo installazione. Verifica python3-pyqt5 e --system-site-packages."
fi

# Verifica VLC e dipendenze sistema
log_info "(Qt) Skip installazione VLC: backend unico Qt"

# Verifica configurazione venv per systemd
log_info "Verifica configurazione virtual environment..."
PYTHON_EXEC="$VENV_DIR/bin/python"
if [ -f "$PYTHON_EXEC" ]; then
  PYTHON_VERSION=$("$PYTHON_EXEC" --version 2>&1)
  log_info "✅ Python venv: $PYTHON_VERSION"
  
  # Test che il venv possa importare i moduli necessari
  if "$PYTHON_EXEC" -c "import sys; print('PYTHON PATH:', sys.path)" >/dev/null 2>&1; then
    log_info "✅ Python path configurato correttamente nel venv"
  else
    log_error "❌ Problemi con la configurazione Python path nel venv"
  fi
else
  log_error "❌ Interprete Python del venv non trovato: $PYTHON_EXEC"
fi

# Verifica che esista il file main.py
log_info "Verifica file principale dell'applicazione..."
MAIN_FILE="$APP_DIR/main.py"
SETTINGS_FILE="$APP_DIR/settings.txt"

if [ -f "$MAIN_FILE" ]; then
  log_info "✅ File principale trovato: main.py"
else
  log_error "❌ File main.py non trovato in: $MAIN_FILE"
  log_error "    Il servizio systemd non potrà avviarsi!"
fi

if [ -f "$SETTINGS_FILE" ]; then
  log_info "✅ File configurazione trovato: settings.txt"
else
  log_warn "⚠️  File settings.txt non trovato in: $SETTINGS_FILE"
  log_warn "    Il servizio userà le configurazioni di default"
fi

# Setup servizio systemd
log_info "Setup servizio systemd..."
SERVICE_FILE=/etc/systemd/system/morocco-player.service
if [ "$(id -u)" != "0" ]; then
  log_warn "Esecuzione non root: salto installazione systemd (rilancia con sudo se vuoi il servizio)."
  exit 0
fi

# Determina utente target e home
TARGET_USER="${SUDO_USER:-$(whoami)}"
TARGET_HOME=$(eval echo "~$TARGET_USER")

# Determina base installazione coerente con UpdateManager
if [ -w "/opt" ]; then
  BASE_DIR="$INSTALL_BASE"
else
  BASE_DIR="$TARGET_HOME/.local/share/vlc_remote"
fi
log_info "Base installazione: $BASE_DIR"
mkdir -p "$BASE_DIR/current" "$BASE_DIR/releases" || true
chown -R "$TARGET_USER":"$TARGET_USER" "$BASE_DIR" 2>/dev/null || true

# Copia/sincronizza codice: condizioni
# 1) current vuota
# 2) variabile FORCE_SYNC=1
# 3) manca sentinella versione (file .bundle_version) o differisce dalla versione bundle corrente (se disponibile)
DO_SYNC=0
if [ -z "$(ls -A "$BASE_DIR/current" 2>/dev/null)" ]; then DO_SYNC=1; fi
if [ "${FORCE_SYNC:-0}" = "1" ]; then DO_SYNC=1; fi

BUNDLE_VERSION_FILE_SRC="$APP_DIR/manifest.txt"
if [ -f "$BUNDLE_VERSION_FILE_SRC" ]; then
  CUR_VER="$(head -n1 "$BUNDLE_VERSION_FILE_SRC" 2>/dev/null | tr -d '\r')"
else
  CUR_VER=""; fi
if [ -f "$BASE_DIR/current/.bundle_version" ]; then
  OLD_VER="$(head -n1 "$BASE_DIR/current/.bundle_version" 2>/dev/null | tr -d '\r')"
else
  OLD_VER=""; fi
if [ "$CUR_VER" != "$OLD_VER" ]; then DO_SYNC=1; fi

if [ "$DO_SYNC" = "1" ]; then
  log_info "Sincronizzo codice applicazione in $BASE_DIR/current (FORCE_SYNC=$FORCE_SYNC, old_ver=$OLD_VER, new_ver=$CUR_VER)"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete \
      --exclude 'venv' \
      --exclude '__pycache__' \
      --exclude '*.pyc' \
      --exclude 'releases' \
      "$APP_DIR/" "$BASE_DIR/current/" 2>/dev/null || true
  else
    cp -r "$APP_DIR"/* "$BASE_DIR/current/" 2>/dev/null || true
  fi
  echo "$CUR_VER" > "$BASE_DIR/current/.bundle_version" 2>/dev/null || true
  chown -R "$TARGET_USER":"$TARGET_USER" "$BASE_DIR/current" 2>/dev/null || true
else
  log_info "Sync codice saltata (versione invariata: $CUR_VER)"
fi

log_info "Creazione file servizio systemd..."
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Morocco Player Qt Server
After=network.target sound.target graphical-session.target
Wants=network.target

[Service]
Type=simple
WorkingDirectory=$BASE_DIR/current
ExecStart=$VENV_DIR/bin/python $BASE_DIR/current/main.py --settings $BASE_DIR/current/settings.txt
Restart=on-failure
RestartSec=5
User=$TARGET_USER

# Variabili d'ambiente
Environment=PYTHONUNBUFFERED=1
Environment=DISPLAY=:0
Environment=PULSE_RUNTIME_PATH=/var/run/pulse
Environment=XDG_RUNTIME_DIR=/run/user/1000
Environment=RESTART_AFTER_UPDATE=1

# Variabili d'ambiente per Python Virtual Environment
Environment=VIRTUAL_ENV=$VENV_DIR
Environment=PATH=$VENV_DIR/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
Environment=PYTHONPATH=$BASE_DIR/current

# Permessi per accesso audio/video
SupplementaryGroups=audio video pulse-access

# (Rimossi DeviceAllow e capabilities VLC)

[Install]
WantedBy=multi-user.target
EOF

log_info "Ricaricamento daemon systemd..."
systemctl daemon-reload

log_info "Abilitazione servizio morocco-player per avvio automatico..."
systemctl enable morocco-player.service

log_info "Avvio immediato del servizio morocco-player..."
if systemctl start morocco-player.service; then
  log_info "Servizio morocco-player avviato con successo!"
  
  # Verifica lo stato del servizio
  sleep 2
  if systemctl is-active --quiet morocco-player.service; then
    log_info "Servizio attivo e funzionante"
  else
    log_warn "Il servizio è stato avviato ma potrebbe avere problemi"
    log_info "Controlla i log con: journalctl -u morocco-player.service -f"
  fi
else
  log_error "Errore durante l'avvio del servizio"
  log_info "Puoi avviarlo manualmente con: systemctl start morocco-player.service"
fi

log_info "Setup completato con successo!"
echo ""
log_info "Configurazione servizio:"
log_info "  - Avvio automatico:  ABILITATO (si avvia al boot)"
log_info "  - Stato attuale:     $(systemctl is-active morocco-player.service 2>/dev/null || echo 'non attivo')"
echo ""
log_info "Comandi utili:"
log_info "  - Avvio servizio:    systemctl start morocco-player.service"
log_info "  - Stop servizio:     systemctl stop morocco-player.service"
log_info "  - Stato servizio:    systemctl status morocco-player.service"
log_info "  - Log servizio:      journalctl -u morocco-player.service -f"

# Funzione per ottenere l'IP locale
get_local_ip() {
  # Prova diversi metodi per ottenere l'IP
  local ip=""
  
  # Metodo 1: ip route (più affidabile)
  if command -v ip >/dev/null 2>&1; then
    ip=$(ip route get 1.1.1.1 2>/dev/null | grep -oP 'src \K\S+' | head -1)
  fi
  
  # Metodo 2: hostname -I (fallback)
  if [ -z "$ip" ] && command -v hostname >/dev/null 2>&1; then
    ip=$(hostname -I 2>/dev/null | awk '{print $1}')
  fi
  
  # Metodo 3: ifconfig (ultimo fallback)
  if [ -z "$ip" ] && command -v ifconfig >/dev/null 2>&1; then
    ip=$(ifconfig 2>/dev/null | grep -oP 'inet \K192\.168\.\d+\.\d+' | head -1)
  fi
  
  # Default se non trovato
  if [ -z "$ip" ]; then
    ip="localhost"
  fi
  
  echo "$ip"
}

# Funzione per leggere le configurazioni da settings.txt
get_port_from_settings() {
  local port_key="$1"
  local default_port="$2"
  local settings_file="$APP_DIR/settings.txt"
  
  if [ -f "$settings_file" ]; then
    local port=$(grep "^$port_key=" "$settings_file" 2>/dev/null | cut -d'=' -f2 | tr -d ' ')
    if [ -n "$port" ]; then
      echo "$port"
    else
      echo "$default_port"
    fi
  else
    echo "$default_port"
  fi
}

# Check finale del servizio e pubblicazione endpoint
echo ""
log_info "═══════════════════════════════════════════════════════════════"
log_info "                    VERIFICA FINALE SERVIZIO                   "
log_info "═══════════════════════════════════════════════════════════════"

# Attendi qualche secondo per essere sicuri che il servizio sia completamente avviato
sleep 3

if systemctl is-active --quiet morocco-player.service; then
  log_info "✅ Servizio Morocco Player ATTIVO e FUNZIONANTE!"
  
  # Ottieni l'IP locale
  LOCAL_IP=$(get_local_ip)
  log_info "🌐 Indirizzo IP rilevato: $LOCAL_IP"
  
  # Leggi le porte dalle configurazioni
  HTTP_PORT=$(get_port_from_settings "HTTP_PORT" "8081")
  UDP_PORT=$(get_port_from_settings "UDP_PORT" "8888")
  TCP_PORT=$(get_port_from_settings "TCP_PORT" "5001")
  OSC_PORT=$(get_port_from_settings "OSC_PORT" "5002")
  
  echo ""
  log_info "🚀 ENDPOINT E PROTOCOLLI DISPONIBILI:"
  echo ""
  log_info "📡 HTTP API Server:"
  log_info "   http://$LOCAL_IP:$HTTP_PORT"
  log_info "   Esempi endpoint:"
  log_info "     • GET  http://$LOCAL_IP:$HTTP_PORT/status"
  log_info "     • POST http://$LOCAL_IP:$HTTP_PORT/play"
  log_info "     • POST http://$LOCAL_IP:$HTTP_PORT/stop"
  log_info "     • POST http://$LOCAL_IP:$HTTP_PORT/fade"
  echo ""
  log_info "📨 UDP Server:"
  log_info "   $LOCAL_IP:$UDP_PORT"
  log_info "   Per comandi veloci e comunicazione real-time"
  echo ""
  log_info "🔌 TCP Server:"
  log_info "   $LOCAL_IP:$TCP_PORT"
  log_info "   Per connessioni persistent e controllo remoto"
  echo ""
  log_info "🎵 OSC Server (Open Sound Control):"
  log_info "   $LOCAL_IP:$OSC_PORT"
  log_info "   Per controllo audio professionale"
  echo ""
  log_info "📋 Test rapido:"
  log_info "   curl http://$LOCAL_IP:$HTTP_PORT/status"
  
else
  log_error "❌ SERVIZIO NON ATTIVO!"
  log_info "🔧 Controlli suggeriti:"
  log_info "   1. Verifica log: journalctl -u morocco-player.service -f"
  log_info "   2. Controlla stato: systemctl status morocco-player.service"
  log_info "   3. Riavvia servizio: systemctl restart morocco-player.service"
  
  # Mostra gli ultimi log per debug
  echo ""
  log_info "📜 Ultimi log del servizio:"
  journalctl -u morocco-player.service --no-pager -n 10 --output=short || echo "Impossibile recuperare i log"
fi

echo ""
log_info "═══════════════════════════════════════════════════════════════"

if is_raspberry_pi && [ "$(id -u)" = "0" ]; then
  echo ""
  log_warn "ATTENZIONE: È stato modificato il file /boot/config.txt"
  log_warn "Per applicare le impostazioni del display è necessario riavviare il sistema:"
  log_warn "  sudo reboot"
fi