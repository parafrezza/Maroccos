#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Richiede: pip install python-osc
from pythonosc import dispatcher, osc_server
import threading

DEBUG = False

def set_debug(flag: bool):
    global DEBUG
    DEBUG = bool(flag)
    print(f"[OSC ] DEBUG {'attivato' if DEBUG else 'disattivato'}")

def get_debug():
    return DEBUG

def _make_handler(cmd_name, commands):
    def _h(addr, *osc_args):
        fn = commands.get(cmd_name)
        if not fn: return
        params = {}
        it = iter(osc_args)
        for k,v in zip(it,it):
            if isinstance(k,str):
                params[k]=str(v)
        if DEBUG: print(f"[OSC ] {addr} /{cmd_name} {params}")
        try: fn(params)
        except Exception as e:
            if DEBUG: print(f"[OSC ] Errore handler {cmd_name}: {e}")
    return _h

def start_osc(host, port, commands, debug=None):
    if debug is not None:
        set_debug(debug)
    disp = dispatcher.Dispatcher()
    for name in commands.keys():
        disp.map(f"/{name}", _make_handler(name, commands))
    server = osc_server.ThreadingOSCUDPServer((host, port), disp)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    if DEBUG: print(f"[OSC ] Server in ascolto su {host}:{port}")
    return server
