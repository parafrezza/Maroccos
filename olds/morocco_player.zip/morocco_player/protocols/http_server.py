import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote
import ssl
import logging

DEBUG = False

# Configura il logger
logger = logging.getLogger("http_server")
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def set_debug(flag: bool):
    global DEBUG
    DEBUG = bool(flag)
    print(f"[HTTP] DEBUG {'attivato' if DEBUG else 'disattivato'}")

def get_debug():
    return DEBUG

class HttpHandler(BaseHTTPRequestHandler):
    commands = {}
    api_key = None
    allowlist = None

    def log_message(self, format, *args):
        # Usa il logger invece di print
        logger.info("%s - %s" % (self.address_string(), format % args))

    def _send(self, data, code=200):
        b = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _client_ip(self):
        return self.client_address[0]

    def _check_auth(self, path):
        # only protect admin paths
        if not path.startswith("admin/"):
            return True, None
        # check allowlist (if provided)
        if self.allowlist:
            ip = self._client_ip()
            if ip not in self.allowlist:
                return False, (403, {"ok": False, "error": "forbidden: ip not allowed"})
        # check api key (if configured)
        if self.api_key:
            # accept X-API-KEY header or Authorization: Bearer <key>
            key = self.headers.get("X-API-KEY") or None
            if not key:
                auth = self.headers.get("Authorization") or ""
                if auth.lower().startswith("bearer "):
                    key = auth[7:].strip()
            if key != self.api_key:
                return False, (401, {"ok": False, "error": "unauthorized"})
        return True, None

    def _dispatch(self, method, parsed, body_params=None):
        cmd = parsed.path.strip("/").lower()
        client_ip = self._client_ip()
        logger.info(f"Ricevuto comando: {cmd}, Metodo: {method}, Origine: {client_ip}")

        if cmd == "":
            # always return (payload, status_code) to avoid unpacking errors
            if DEBUG: print(f"[HTTP][DISPATCH] path='/' returning commands list")
            return {"ok": True, "commands": sorted(self.commands.keys())}, 200

        ok, err = self._check_auth(cmd)
        if not ok:
            code, payload = err
            return payload, code

        params = {k: unquote(v[0]) for k, v in parse_qs(parsed.query).items()}
        if body_params:
            # merge, body params override query
            params.update(body_params)

        if DEBUG:
            try:
                print(f"[HTTP][DISPATCH] method={method} cmd={cmd} params={params} body={body_params}")
            except Exception:
                pass

        fn = self.commands.get(cmd)
        if not fn:
            return {"ok": False, "error": "unknown command"}, 404
        try:
            res = fn(params)
            logger.info(f"Comando eseguito: {cmd}, Risultato: {res}")
            if DEBUG:
                print(f"[HTTP][DISPATCH] result for {cmd}: {res}")
            return res, 200
        except Exception as e:
            logger.error(f"Errore durante l'esecuzione del comando {cmd}: {e}")
            if DEBUG:
                print(f"[HTTP][DISPATCH][ERROR] {e}")
            return {"ok": False, "error": str(e)}, 500

    def do_GET(self):
        parsed = urlparse(self.path)
        if DEBUG: print(f"[HTTP] GET {parsed.path} from {self.client_address[0]}")
        result = self._dispatch("GET", parsed)
        if isinstance(result, tuple):
            res, code = result
        else:
            res, code = result, 200
        try:
            code = int(code)
        except Exception:
            code = 200
        self._send(res, code)

    def do_POST(self):
        parsed = urlparse(self.path)
        if DEBUG: print(f"[HTTP] POST {parsed.path} from {self.client_address[0]}")
        content_length = int(self.headers.get('Content-Length', 0))
        body = None
        if content_length:
            raw = self.rfile.read(content_length)
            try:
                body = json.loads(raw.decode('utf-8'))
            except Exception:
                # try form-encoded fallback
                try:
                    qs = parse_qs(raw.decode('utf-8'))
                    body = {k: v[0] for k, v in qs.items()}
                except Exception:
                    body = None
        result = self._dispatch('POST', parsed, body_params=body or {})
        if isinstance(result, tuple):
            res, code = result
        else:
            res, code = result, 200
        try:
            code = int(code)
        except Exception:
            code = 200
        self._send(res, code)


def start_http(host, port, commands, certfile=None, keyfile=None, api_key=None, allowlist=None, debug=None):
    if debug is not None:
        set_debug(debug)
    HttpHandler.commands = commands
    HttpHandler.api_key = api_key
    HttpHandler.allowlist = allowlist
    srv = ThreadingHTTPServer((host, port), HttpHandler)
    # optional TLS
    if certfile and keyfile and os.path.exists(certfile) and os.path.exists(keyfile):
        context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        context.load_cert_chain(certfile=certfile, keyfile=keyfile)
        srv.socket = context.wrap_socket(srv.socket, server_side=True)
    if DEBUG: print(f"[HTTP] Server in ascolto su {host}:{port}")
    return srv

def download_command(params):
    import requests
    import mimetypes
    from pathlib import Path

    url = params.get("url")
    if not url:
        return {"ok": False, "error": "missing 'url' parameter"}
    try:
        # Effettua il download del file
        logger.info(f"Downloading file from {url}")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        # Determina il nome del file e il tipo MIME
        content_type = response.headers.get('Content-Type')
        extension = mimetypes.guess_extension(content_type) or ''
        filename = Path(url).name
        if not filename.endswith(extension):
            filename += extension

        # Percorso di salvataggio nella cartella ./media
        media_dir = Path("./media")
        media_dir.mkdir(exist_ok=True)
        file_path = media_dir / filename

        # Salva il file
        with open(file_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        # Verifica se il file è immagine o video e non ha grandezza 0
        if file_path.stat().st_size == 0:
            file_path.unlink()  # Rimuove il file vuoto
            return {"ok": False, "error": "downloaded file is empty"}

        if content_type and not content_type.startswith(('image/', 'video/')):
            file_path.unlink()  # Rimuove il file non valido
            return {"ok": False, "error": "file is not an image or video"}

        return {"ok": True, "message": f"File downloaded and saved to {file_path}"}
    except Exception as e:
        logger.error(f"Errore durante il download: {e}")
        return {"ok": False, "error": str(e)}

# Aggiungi il comando alla lista dei comandi disponibili
HttpHandler.commands["download"] = download_command
