#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket, threading, json, os

DEBUG = True if ("MOROCCO_DEBUG" in os.environ and os.environ["MOROCCO_DEBUG"].lower() in ("1","true","yes")) else False

# aggiunte funzioni debug runtime
def set_debug(flag: bool):
    global DEBUG
    DEBUG = bool(flag)
    print(f"[UDP] DEBUG {'attivato' if DEBUG else 'disattivato'}")

def get_debug():
    return DEBUG

def parse_line(line: str):
    parts = line.strip().split()
    if not parts: return None, {}
    cmd = parts[0].lower()
    params = {}
    for token in parts[1:]:
        if "=" in token:
            k,v = token.split("=",1)
            params[k]=v
    return cmd, params

def start_udp(host, port, commands, respond=False, debug=None):
    global DEBUG
    if debug is not None:
        DEBUG = bool(debug)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    except Exception:
        pass
    sock.bind((host, port))
    if DEBUG: print(f"[UDP] Server in ascolto su {host}:{port} respond={respond}")
    def loop():
        while True:
            try:
                data, addr = sock.recvfrom(4096)
            except OSError as e:
                if DEBUG: print(f"[UDP] recv errore: {e}")
                continue
            line = data.decode(errors="ignore")
            if DEBUG: print(f"[UDP] {addr} -> {line.rstrip()}")
            cmd, params = parse_line(line)
            if not cmd:
                continue
            fn = commands.get(cmd)
            if not fn:
                if respond:
                    try: sock.sendto(b'{"ok":false,"error":"unknown"}', addr)
                    except OSError: pass
                continue
            try:
                res = fn(params)
            except Exception as e:
                res = {"ok": False, "error": str(e)}
            if respond:
                try:
                    sock.sendto(json.dumps(res).encode(), addr)
                except OSError as e:
                    if DEBUG: print(f"[UDP] sendto errore verso {addr}: {e}")
    th = threading.Thread(target=loop, daemon=True); th.start()
    return sock
