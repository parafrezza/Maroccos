#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket, threading, json, sys, os

# funzione per calcolare debug da ambiente (fallback)
def _env_debug():
    return ("MOROCCO_DEBUG" in os.environ and os.environ["MOROCCO_DEBUG"].lower() in ("1","true","yes"))

DEBUG = _env_debug()

def set_debug(flag: bool):
    global DEBUG
    DEBUG = bool(flag)
    if DEBUG:
        print("[TCP] DEBUG attivato")
    else:
        print("[TCP] DEBUG disattivato")

def parse_line(line: str):
    parts = line.strip().split()
    if not parts: return None, {}
    cmd = parts[0].lower()
    params = {}
    for token in parts[1:]:
        if "=" in token:
            k,v = token.split("=",1)
            params[k]=v
    return cmd, params

def handle_client(conn, addr, commands):
    if DEBUG: print(f"[TCP] Connessione aperta da {addr}")
    try:
        with conn:
            f = conn.makefile("r")
            while True:
                try:
                    line = f.readline()
                    if not line:  # EOF
                        break
                    cmd, params = parse_line(line)
                    if not cmd: 
                        continue
                    fn = commands.get(cmd)
                    if not fn:
                        resp = {"ok": False, "error": "unknown"}
                    else:
                        try:
                            resp = fn(params)
                        except Exception as e:
                            resp = {"ok": False, "error": str(e)}
                    try:
                        conn.sendall((json.dumps(resp)+"\n").encode())
                    except (BrokenPipeError, ConnectionResetError) as e:
                        if DEBUG: print(f"[TCP] Invio fallito verso {addr}: {e}")
                        break
                except (ConnectionResetError, ConnectionAbortedError) as e:
                    if DEBUG: print(f"[TCP] Connessione interrotta da {addr}: {e}")
                    break
                except OSError as e:
                    if DEBUG: print(f"[TCP] Errore socket {addr}: {e}")
                    break
    finally:
        if DEBUG: print(f"[TCP] Connessione chiusa {addr}")

def start_tcp(host, port, commands, debug=None):
    global DEBUG
    if debug is not None:
        DEBUG = bool(debug)
    elif DEBUG is None:  # se mai fosse None, calcola
        DEBUG = _env_debug()
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    except Exception:
        pass
    srv.bind((host, port))
    srv.listen(5)
    if DEBUG: print(f"[TCP] Server in ascolto su {host}:{port}")
    def accept_loop():
        while True:
            try:
                c,a = srv.accept()
            except OSError as e:
                if DEBUG: print(f"[TCP] accept() errore: {e}")
                continue
            threading.Thread(target=handle_client, args=(c,a,commands), daemon=True).start()
    threading.Thread(target=accept_loop, daemon=True).start()
    return srv
