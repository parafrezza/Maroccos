import threading, time, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import requests
from protocols.http_server import start_http, set_debug


@pytest.fixture(scope="module")
def http_server():
    # build full command set from project controller
    from api.controller import PlayerController
    from api.commands import build_commands
    from api.updater import UpdateManager

    ctrl = PlayerController()
    commands = build_commands(ctrl)

    # minimal Admin endpoints (non-downloading updater)
    um = UpdateManager(base=Path.cwd() / "test_releases")
    commands["version"] = lambda p: {"ok": True, "manifest": None}
    commands["admin/update/status"] = lambda p: um.status_get()
    commands["admin/drain"] = lambda p: {"ok": True, "drained": True}
    commands["admin/undrain"] = lambda p: {"ok": True, "drained": False}
    srv = start_http('127.0.0.1', 8099, commands, debug=True)
    thr = threading.Thread(target=srv.serve_forever, daemon=True)
    thr.start()
    time.sleep(0.1)
    yield
    try:
        srv.shutdown(); srv.server_close()
    except Exception:
        pass


def test_root_and_ping(http_server):
    r = requests.get('http://127.0.0.1:8099/')
    assert r.status_code == 200
    j = r.json()
    assert j.get('ok') is True
    # exercise some commands
    r_status = requests.get('http://127.0.0.1:8099/status')
    assert r_status.status_code == 200
    assert 'state' in r_status.json()

    r_play = requests.get('http://127.0.0.1:8099/play')
    assert r_play.status_code == 200

    r_pause = requests.get('http://127.0.0.1:8099/pause')
    assert r_pause.status_code == 200

    r_pl_add = requests.get('http://127.0.0.1:8099/playlist_add?input=4.mp4')
    assert r_pl_add.status_code == 200

    r_ver = requests.get('http://127.0.0.1:8099/version')
    assert r_ver.status_code == 200

    r_drain = requests.post('http://127.0.0.1:8099/admin/drain', json={})
    assert r_drain.status_code == 200


def test_black_command(http_server):
    import requests, time
    # call black instant
    r = requests.get('http://127.0.0.1:8099/black')
    assert r.status_code == 200
    # poll status (vlc may need a tick to apply adjustments)
    ok = False
    for _ in range(10):
        st = requests.get('http://127.0.0.1:8099/status').json()
        if st.get('brightness', 1) <= 0.01 and st.get('contrast', 1) <= 0.01:
            ok = True
            break
        time.sleep(0.05)
    assert ok, f"Expected brightness/contrast ~0 got {st}"

