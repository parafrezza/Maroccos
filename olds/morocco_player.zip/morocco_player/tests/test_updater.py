import io, os, zipfile, tempfile, shutil, sys
from pathlib import Path
import pytest

# Ensure project root is importable for tests
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from api.updater import UpdateManager


def make_bundle(tmpdir, version="9.9.9"):
    d = Path(tmpdir) / f"morocco-player-v{version}"
    d.mkdir(parents=True)
    (d / "manifest.txt").write_text(f"version={version}\n")
    z = Path(tmpdir) / "bundle.zip"
    with zipfile.ZipFile(z, "w") as zf:
        for p in d.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(tmpdir))
    return str(z)


def test_apply_and_status(tmp_path, monkeypatch):
    um = UpdateManager(base=tmp_path)

    # create a fake bundle file and patch the download to copy it instead
    fake_zip = make_bundle(tmp_path, version="1.2.3")

    def fake_download(url, dest):
        shutil.copy(fake_zip, dest)

    monkeypatch.setattr(um, "_download", fake_download)

    r = um.apply("1.2.3", "http://example/bundle.zip", sha256="dummysha")
    # since sha mismatch should return error
    assert r["ok"] is False or r.get("error") in ("sha256_mismatch",)

    # Now compute correct sha and try again
    import hashlib
    h = hashlib.sha256()
    with open(fake_zip, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    good = h.hexdigest()

    r2 = um.apply("1.2.3", "http://example/bundle.zip", sha256=good)
    assert r2.get("ok") is True
    # status should report ok
    s = um.status_get()
    assert s["status"]["phase"] in ("ok","warning")


def test_rollback_no_releases(tmp_path):
    um = UpdateManager(base=tmp_path)
    r = um.rollback()
    assert r["ok"] is False


def test_check(monkeypatch, tmp_path):
    from api.updater import UpdateManager
    um = UpdateManager(base=tmp_path)
    import urllib.request as _urllib

    def fake_urlopen(req, timeout=10):
        class _Resp:
            def __enter__(self): return self
            def __exit__(self, *a): pass
            def read(self):
                return b'{"versions":[{"version":"1.0.0"}]}'
        # accetta sia string che Request
        return _Resp()

    monkeypatch.setattr(_urllib, "urlopen", fake_urlopen)
    r = um.check("http://example/versions.json")
    assert r.get("ok") is True
    assert isinstance(r.get("versions"), dict)
    assert r["versions"].get("versions")[0]["version"] == "1.0.0"
