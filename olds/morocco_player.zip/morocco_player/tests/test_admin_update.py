import threading, time, sys, shutil
from pathlib import Path
import json
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import requests
from protocols.http_server import start_http
from api.updater import UpdateManager


def make_bundle(tmpdir, version="2.0.0"):
    d = Path(tmpdir) / f"morocco-player-v{version}"
    d.mkdir(parents=True)
    (d / "manifest.txt").write_text(f"version={version}\n")
    z = Path(tmpdir) / "bundle.zip"
    import zipfile
    with zipfile.ZipFile(z, "w") as zf:
        for p in d.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(tmpdir))
    return str(z)


@pytest.fixture()
def admin_server(tmp_path):
    # Setup UpdateManager pointing to a releases dir inside tmp_path
    um_base = tmp_path / "um_base"
    um = UpdateManager(base=um_base)

    # create a fake bundle
    bz = make_bundle(tmp_path, version="2.0.0")

    # stub download to copy local file
    def fake_download(url, dest):
        shutil.copy(bz, dest)

    um._download = fake_download

    # commands exposing apply/status/rollback
    def apply_cmd(p):
        # expect p to contain version,url,sha256
        return um.apply(p.get("version"), p.get("url"), p.get("sha256"))

    def status_cmd(p):
        return um.status_get()

    def rollback_cmd(p):
        return um.rollback()

    commands = {
        "admin/update/apply": apply_cmd,
        "admin/update/status": status_cmd,
        "admin/update/rollback": rollback_cmd,
    }

    srv = start_http('127.0.0.1', 8110, commands, debug=True)
    thr = threading.Thread(target=srv.serve_forever, daemon=True)
    thr.start()
    time.sleep(0.1)
    yield {"url_root": "http://127.0.0.1:8110", "bundle": bz}
    try:
        srv.shutdown(); srv.server_close()
    except Exception:
        pass


def test_apply_and_rollback(admin_server):
    root = admin_server["url_root"]
    # compute sha256 of fake bundle created by fixture
    import hashlib
    bz_path = Path(admin_server["bundle"])
    h = hashlib.sha256()
    with open(bz_path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    good_sha = h.hexdigest()

    # First call with wrong sha
    r = requests.post(f"{root}/admin/update/apply", json={"version": "2.0.0", "url": "ignored", "sha256": "deadbeef"})
    assert r.status_code == 200
    j = r.json()
    assert j.get('ok') in (False,)

    # Now call with correct sha
    r2 = requests.post(f"{root}/admin/update/apply", json={"version": "2.0.0", "url": "ignored", "sha256": good_sha})
    assert r2.status_code == 200
    j2 = r2.json()
    # depending on implementation, apply may return ok True
    assert j2.get('ok') in (True, False)  # accept both but ensure status endpoint reports something

    # Poll status until ok or timeout
    for _ in range(20):
        rs = requests.get(f"{root}/admin/update/status")
        assert rs.status_code == 200
        sj = rs.json()
        phase = sj.get('status', {}).get('phase')
        if phase in ('ok', 'warning'):
            break
        time.sleep(0.1)
    assert phase in ('ok', 'warning')

    # rollback
    rr = requests.post(f"{root}/admin/update/rollback", json={})
    assert rr.status_code == 200
    assert rr.json().get('ok') in (True, False)
