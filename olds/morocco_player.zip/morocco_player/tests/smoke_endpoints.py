import os
import time
import json
import urllib.request

BASE = os.environ.get("PLAYER_BASE", "http://192.168.1.42:8080")
DEFAULT_TIMEOUT = int(os.environ.get("SMOKE_TIMEOUT", "10"))


def req(method, path, data=None, timeout=DEFAULT_TIMEOUT, retries=3, backoff=1.5):
    url = BASE + path
    body = None
    headers = {"Content-Type": "application/json"}
    if data is not None:
        body = json.dumps(data).encode("utf-8")
    last_exc = None
    for i in range(retries):
        try:
            r = urllib.request.Request(url, data=body, headers=headers, method=method)
            with urllib.request.urlopen(r, timeout=timeout) as resp:
                ct = resp.headers.get("Content-Type", "")
                payload = resp.read()
                try:
                    return resp.status, json.loads(payload)
                except Exception:
                    return resp.status, {"raw": payload.decode(errors="ignore"), "content_type": ct}
        except Exception as e:
            last_exc = e
            time.sleep(backoff * (i + 1))
    raise last_exc

def wait_for(cond_fn, timeout=60, interval=1.0):
    start = time.time()
    last = None
    while time.time() - start < timeout:
        ok, data = cond_fn()
        if ok:
            return True, data
        last = data
        time.sleep(interval)
    return False, last


def main():
    logs = []
    def log(*a):
        s = " ".join(str(x) for x in a)
        print(s)
        logs.append(s)

    # healthz
    code, res = req("GET", "/healthz", timeout=DEFAULT_TIMEOUT)
    log("healthz", code, res)

    # status
    code, res = req("GET", "/status", timeout=DEFAULT_TIMEOUT)
    log("status", code, res)

    # list media
    code, res = req("GET", "/media", timeout=DEFAULT_TIMEOUT)
    log("media", code, len(res) if isinstance(res, list) else res)

    # create playlist
    code, res = req("POST", "/media/playlist", {"loop": True}, timeout=DEFAULT_TIMEOUT)
    log("playlist", code, res)

    # status
    code, res = req("GET", "/playlist/status", timeout=DEFAULT_TIMEOUT)
    log("pl-status", code, res)

    # play first
    code, res = req("POST", "/play", {"hide_splash_first": True, "fade_in_seconds": 0.5}, timeout=DEFAULT_TIMEOUT)
    log("play", code, res)
    # wait until state becomes playing (slow devices)
    def cond_playing():
        try:
            c, s = req("GET", "/status", timeout=DEFAULT_TIMEOUT)
            return (c == 200 and s.get("player_state") == "playing"), s
        except Exception as e:
            return False, {"error": str(e)}
    ok, data = wait_for(cond_fn=cond_playing, timeout=90, interval=2.0)
    log("wait_playing", ok, data.get("player_state") if isinstance(data, dict) else data)

    # next
    code, res = req("POST", "/playlist/next", timeout=DEFAULT_TIMEOUT)
    log("next", code, res)
    # wait and prev
    ok, data = wait_for(cond_fn=cond_playing, timeout=60, interval=2.0)
    log("wait_next_playing", ok)
    code, res = req("POST", "/playlist/prev", timeout=DEFAULT_TIMEOUT)
    log("prev", code, res)

    # fade out/in
    code, res = req("POST", "/fade_out", {"seconds": 0.5}, timeout=DEFAULT_TIMEOUT)
    log("fade_out", code, res)
    time.sleep(1.0)
    code, res = req("POST", "/fade_in", {"seconds": 0.5}, timeout=DEFAULT_TIMEOUT)
    log("fade_in", code, res)

    # collect final status
    code, res = req("GET", "/status", timeout=DEFAULT_TIMEOUT)
    log("status-end", code, res)

    print("\n=== SMOKE LOG START ===")
    for l in logs:
        print(l)
    print("=== SMOKE LOG END ===")


if __name__ == "__main__":
    main()
