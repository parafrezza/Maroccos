#!/usr/bin/env python3
# Minimal test player: avvia Qt, carica un file e lo riproduce in loop continuo.
# Uso: python simple_player.py --file media/s1.mp4 (o percorso/URL)

import argparse, os, time, threading, sys
from api.controller_qt import QtPlayerController

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', '-f', default='media/s1.mp4', help='File locale o URL da riprodurre in loop')
    ap.add_argument('--loop', action='store_true', help='Forza loop_one sul file')
    ap.add_argument('--no-info', action='store_true', help='Disabilita overlay IP/versione')
    args = ap.parse_args()

    ctrl = QtPlayerController(version_text='TEST', show_info=not args.no_info)

    path = args.file
    if not (path.startswith('http://') or path.startswith('https://')):
        if not os.path.exists(path):
            print('[TEST] File non trovato:', path)
        else:
            print('[TEST] File trovato:', path)

    if args.loop:
        ctrl.loop_one(path, on=True)

    ctrl.load(path)
    ctrl.play()

    print('[TEST] Stato iniziale:', ctrl.status())

    try:
        while True:
            time.sleep(5)
            st = ctrl.status()
            print('[TEST] status:', st)
            # Se playback fermo, rilancia
            if st.get('state') != 'playing':
                ctrl.play()
    except KeyboardInterrupt:
        print('\n[TEST] Uscita richiesta')

if __name__ == '__main__':
    main()
