import os, io, threading, socket, shutil, tarfile, zipfile, time
from pathlib import Path
import subprocess
from typing import Optional
from urllib.request import urlopen, Request

from fastapi import FastAPI, Query, Body
from fastapi.responses import JSONResponse
import uvicorn

from PIL import Image, ImageDraw, ImageFont
import netifaces
import json

import gi
gi.require_version("Gst", "1.0")
gi.require_version("GObject", "2.0")
from gi.repository import Gst, GObject, GLib

# ---------- Config ----------
APP_DIR = Path(__file__).resolve().parent
MEDIA_DIR = APP_DIR / "media"
MEDIA_DIR.mkdir(exist_ok=True)
VERSION_FILE = APP_DIR / "VERSION"
VERSION = VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "v0.1.0"
USE_KMS = os.environ.get("USE_KMS", "1") == "1"
USE_HW_DECODER = os.environ.get("USE_HW_DECODER", "1") == "1"
TARGET_WIDTH = int(os.environ.get("TARGET_WIDTH", "1280"))
TARGET_HEIGHT = int(os.environ.get("TARGET_HEIGHT", "720"))
TARGET_FPS = os.environ.get("TARGET_FPS", "25/1")
FADE_INTERVAL_MS = 50
VIDEO_PATH = str(MEDIA_DIR / "orcanmado.mp4")
APP_PORT = int(os.environ.get("APP_PORT", "8080"))
SPLASH_BLACK = os.environ.get("SPLASH_BLACK", "0") == "1"

# Crea un video di test se non esiste
def create_test_video():
    if not Path(VIDEO_PATH).exists():
        print(f"[INIT] Creo video di test: {VIDEO_PATH}", flush=True)
        # Crea un video di test usando GStreamer
        cmd = f'gst-launch-1.0 videotestsrc pattern=0 num-buffers=150 ! "video/x-raw,width=1280,height=720,framerate=25/1" ! x264enc ! h264parse ! mp4mux ! filesink location="{VIDEO_PATH}"'
        os.system(cmd)
        if Path(VIDEO_PATH).exists():
            print(f"[INIT] Video di test creato: {VIDEO_PATH}", flush=True)
        else:
            print(f"[INIT] ERRORE: Impossibile creare video di test", flush=True)

# Disabilita la creazione automatica del video test salvo esplicita richiesta (CREATE_TEST_VIDEO=1)
if os.environ.get("CREATE_TEST_VIDEO", "0") == "1":
    create_test_video()
# ----------------------------

Gst.init(None)
# GObject.threads_init()

app = FastAPI(title="Headless Video Player")

main_loop = GLib.MainLoop()
player = {"pipeline": None, "vb": None, "alpha": None, "loop": False, "state": "stopped"}
playlist = {"items": [], "index": -1, "loop": True}
splash = {"pipeline": None, "active": False}  # Aggiungiamo tracking per il splash
preloaded = {"path": None, "pipeline": None, "vb": None, "alpha": None}  # Pipeline pre-caricata per prossimo elemento playlist
fade_seq = 0  # Sequenziatore per cancellare fade sovrapposti

current_update = {
    "available": None,
    "status": "idle",
    "log": [],
    "callback_url": None,
    "progress": 0,
    "error": None,
    "bytes_total": 0,
    "bytes_done": 0,
}

# ---------- Maintenance ----------
maintenance = {
    "status": "idle",  # idle | running | ok | error
    "log": [],
    "error": None,
}

def log_maintenance(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    maintenance["log"].append(line)
    maintenance["log"] = maintenance["log"][-300:]
def log_update(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    current_update["log"].append(line)
    current_update["log"] = current_update["log"][-200:]
    if current_update["callback_url"]:
        try:
            import urllib.request
            req = urllib.request.Request(
                current_update["callback_url"],
                data=json.dumps({"message": line, "status": current_update["status"]}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass

def get_ip():
    for iface in netifaces.interfaces():
        addrs = netifaces.ifaddresses(iface).get(netifaces.AF_INET, [])
        for a in addrs:
            ip = a.get('addr')
            if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
                return ip
    return "0.0.0.0"

def get_eth_wifi_ips():
    """Ritorna (eth_ip, wifi_ip) se presenti, altrimenti None."""
    eth_ip = None
    wifi_ip = None
    for iface in netifaces.interfaces():
        iname = (iface or "").lower()
        addrs = netifaces.ifaddresses(iface).get(netifaces.AF_INET, [])
        for a in addrs:
            ip = a.get('addr')
            if not ip or ip.startswith("127.") or ip.startswith("169.254."):
                continue
            if iname.startswith(("eth", "enp", "eno", "ens")):
                if not eth_ip:
                    eth_ip = ip
            elif iname.startswith(("wlan", "wl")):
                if not wifi_ip:
                    wifi_ip = ip
    return eth_ip, wifi_ip

# ---------- Splash via appsrc ----------
def build_splash_pipeline():
    """Crea la pipeline splash con fallback automatico da kmssink ad autovideosink."""
    preferred = "kmssink" if USE_KMS else "autovideosink"
    tried = []
    for sink in [preferred, "autovideosink"]:
        if sink in tried:
            continue
        tried.append(sink)
        try:
            desc = (
                f"appsrc name=src is-live=true format=time caps=video/x-raw,format=RGB,width={TARGET_WIDTH},height={TARGET_HEIGHT},framerate=30/1 "
                f"! videoconvert ! videobalance name=svb ! imagefreeze ! {sink}"
            )
            pipeline = Gst.parse_launch(desc)
            return pipeline, pipeline.get_by_name("src"), pipeline.get_by_name("svb")
        except Exception as e:
            print(f"[SPLASH] Errore creazione pipeline con {sink}: {e}", flush=True)
            continue
    raise RuntimeError("Impossibile creare pipeline splash")

def push_splash_frame(appsrc):
    print("[SPLASH] Generazione frame splash", flush=True)
    img = Image.new("RGB", (TARGET_WIDTH, TARGET_HEIGHT), (0, 0, 0))
    if not SPLASH_BLACK:
        eth_ip, wifi_ip = get_eth_wifi_ips()
        text = (
            f"eth -> {eth_ip or '-'}\n"
            f"wifi -> {wifi_ip or '-'}\n"
            f"Versione: {VERSION}"
        )
        print(f"[SPLASH] Testo: {text}", flush=True)
        d = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 32)
        except:
            font = ImageFont.load_default()
        # Centra il testo
        try:
            w, h = d.multiline_textbbox((0,0), text, font=font, align="center")[2:]
        except Exception:
            w, h = d.multiline_textsize(text, font=font)
        d.multiline_text(((TARGET_WIDTH - w) // 2, (TARGET_HEIGHT - h) // 2), text, fill=(255, 255, 255), font=font, align="center")
    buf = Gst.Buffer.new_allocate(None, TARGET_WIDTH * TARGET_HEIGHT * 3, None)
    buf.fill(0, img.tobytes())
    now = int(time.time() * Gst.SECOND)
    buf.pts = buf.dts = now
    result = appsrc.emit("push-buffer", buf)
    print(f"[SPLASH] Frame inviato, risultato: {result}", flush=True)

def push_custom_splash_frame(appsrc, extra_line: str | None = None):
    """Disegna lo stesso splash ma con una riga extra (es. PING!)"""
    img = Image.new("RGB", (TARGET_WIDTH, TARGET_HEIGHT), (0, 0, 0))
    eth_ip, wifi_ip = get_eth_wifi_ips()
    base = (
        f"eth -> {eth_ip or '-'}\n"
        f"wifi -> {wifi_ip or '-'}\n"
        f"Versione: {VERSION}"
    )
    text = base if not extra_line else (base + f"\n{extra_line}")
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 32)
    except:
        font = ImageFont.load_default()
    try:
        w, h = d.multiline_textbbox((0,0), text, font=font, align="center")[2:]
    except Exception:
        w, h = d.multiline_textsize(text, font=font)
    d.multiline_text(((TARGET_WIDTH - w) // 2, (TARGET_HEIGHT - h) // 2), text, fill=(255, 255, 255), font=font, align="center")
    buf = Gst.Buffer.new_allocate(None, TARGET_WIDTH * TARGET_HEIGHT * 3, None)
    buf.fill(0, img.tobytes())
    now = int(time.time() * Gst.SECOND)
    buf.pts = buf.dts = now
    appsrc.emit("push-buffer", buf)

def show_splash_until_play():
    print("[SPLASH] Avvio splash permanente", flush=True)
    pipeline, src, vb = build_splash_pipeline()
    splash["pipeline"] = pipeline
    splash["src"] = src
    splash["vb"] = vb
    splash["active"] = True
    pipeline.set_state(Gst.State.PLAYING)
    GLib.idle_add(push_splash_frame, src)
    print("[SPLASH] Splash avviato (attivo fino al primo play)", flush=True)

def hide_splash():
    if splash["active"] and splash["pipeline"]:
        print("[SPLASH] Chiudo splash", flush=True)
        splash["pipeline"].set_state(Gst.State.NULL)
        splash["pipeline"] = None
        splash["active"] = False
        print("[SPLASH] Splash chiuso", flush=True)

# ---------- Player pipeline ----------
def decoder_name():
    res = os.popen("gst-inspect-1.0 v4l2h264dec 2>/dev/null").read()
    return "v4l2h264dec" if "v4l2h264dec" in res else "avdec_h264"

def build_player_pipeline(path):
    sink = "kmssink" if USE_KMS else "autovideosink"
    dec = "decodebin"
    # Nota: su RPi potresti usare v4l2h264dec se disponibile (già funzione decoder_name se serve)
    if USE_HW_DECODER:
        # Preferisci decodebin (che può usare hw) per compatibilità; potremmo forzare caps in futuro
        dec = "decodebin"
    caps_filter = f"video/x-raw,width={TARGET_WIDTH},height={TARGET_HEIGHT},framerate={TARGET_FPS}"
    # Nota: path quotato per evitare errori con spazi o caratteri speciali
    desc = (
        f"filesrc location=\"{path}\" ! queue ! {dec} name=dec ! queue ! videoconvert ! videoscale ! "
        f"videorate ! {caps_filter} ! videoconvert ! video/x-raw,format=RGBA ! alpha name=af ! videoconvert ! "
        f"videobalance name=vb ! {sink}"
    )
    print(f"[PLAYER] Pipeline: {desc}", flush=True)
    try:
        pipeline = Gst.parse_launch(desc)
        vb = pipeline.get_by_name("vb")
        af = pipeline.get_by_name("af")
        bus = pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message", on_bus_message, None)
        decbin = pipeline.get_by_name("dec")
        if decbin:
            def on_pad_added(db, pad):
                caps = pad.get_current_caps() or pad.query_caps()
                if not caps:
                    return
                s = caps.get_structure(0)
                if not s or not s.get_name().startswith("video/"):
                    return
                if s.has_field("framerate"):
                    try:
                        ok, num, den = s.get_fraction("framerate")
                        if ok and num and den:
                            real = f"{num}/{den}"
                            if real != TARGET_FPS:
                                print(f"[FRAMERATE] Sorgente {real} (target {TARGET_FPS})", flush=True)
                    except Exception as fe:
                        print(f"[FRAMERATE] Errore lettura framerate: {fe}", flush=True)
                if s.has_field("width") and s.has_field("height"):
                    w = s.get_int("width")[1]; h = s.get_int("height")[1]
                    print(f"[VIDEO] Stream {w}x{h}", flush=True)
            decbin.connect("pad-added", on_pad_added)
        return pipeline, vb, af
    except Exception as e:
        # Se fallisce con kmssink e USE_KMS attivo prova fallback
        if USE_KMS:
            print(f"[PLAYER] Errore con kmssink: {e} -> fallback autovideosink", flush=True)
            try:
                fb_desc = desc.replace("kmssink", "autovideosink")
                pipeline = Gst.parse_launch(fb_desc)
                vb = pipeline.get_by_name("vb")
                af = pipeline.get_by_name("af")
                bus = pipeline.get_bus(); bus.add_signal_watch(); bus.connect("message", on_bus_message, None)
                decbin = pipeline.get_by_name("dec")
                if decbin:
                    def on_pad_added(db, pad):
                        caps = pad.get_current_caps() or pad.query_caps()
                        if not caps:
                            return
                        s = caps.get_structure(0)
                        if not s or not s.get_name().startswith("video/"):
                            return
                        if s.has_field("framerate"):
                            try:
                                ok, num, den = s.get_fraction("framerate")
                                if ok and num and den:
                                    real = f"{num}/{den}"
                                    if real != TARGET_FPS:
                                        print(f"[FRAMERATE] Sorgente {real} (target {TARGET_FPS})", flush=True)
                            except Exception as fe:
                                print(f"[FRAMERATE] Errore lettura framerate: {fe}", flush=True)
                        if s.has_field("width") and s.has_field("height"):
                            w = s.get_int("width")[1]; h = s.get_int("height")[1]
                            print(f"[VIDEO] Stream {w}x{h}", flush=True)
                    decbin.connect("pad-added", on_pad_added)
                print("[PLAYER] Fallback autovideosink attivo", flush=True)
                return pipeline, vb, af
            except Exception as e2:
                print(f"[PLAYER] Fallback autovideosink fallito: {e2}", flush=True)
        print(f"[PLAYER] ERRORE nella creazione pipeline: {e}", flush=True)
        raise

def pipeline_has_kmssink(p: Gst.Pipeline) -> bool:
    try:
        it = p.iterate_elements()
        ok, elem = it.next()
        while ok:
            try:
                fac = elem.get_factory()
                if fac and fac.get_name() == "kmssink":
                    return True
            except Exception:
                pass
            ok, elem = it.next()
    except Exception:
        pass
    return False

def on_bus_message(bus, msg, data):
    t = msg.type
    if t == Gst.MessageType.EOS:
        print("[PLAYER] Fine del video (EOS)", flush=True)
        # Avanzamento playlist se presente
        if playlist["items"]:
            next_index = playlist["index"] + 1
            if next_index >= len(playlist["items"]):
                if playlist["loop"]:
                    next_index = 0
                else:
                    # Fine playlist
                    if player["pipeline"]:
                        player["pipeline"].set_state(Gst.State.NULL)
                    player["state"] = "stopped"
                    print("[PLAYER] Fine playlist", flush=True)
                    return
            playlist["index"] = next_index
            next_path = playlist["items"][next_index]
            print(f"[PLAYLIST] Avanzo a: {next_path}", flush=True)
            # Aggiorna path e adotta se precaricata
            global VIDEO_PATH
            VIDEO_PATH = next_path
            if not adopt_preloaded(next_path):
                stop_play()
                start_play_with_path(next_path)
            return
        # Nessuna playlist: comportamento originale loop singolo
        if player["loop"] and player["pipeline"]:
            print("[PLAYER] Riavvio loop", flush=True)
            player["pipeline"].seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, 0)
        else:
            stop_play()
            print("[PLAYER] Riproduzione terminata", flush=True)
            if not splash["active"]:
                show_splash_until_play()
    elif t == Gst.MessageType.ERROR:
        err, debug = msg.parse_error()
        print(f"[PLAYER] GST ERROR: {err}", flush=True)
        print(f"[PLAYER] Debug info: {debug}", flush=True)
        # Fallback automatico: se kmssink va in errore (permessi DRM o altro), passa ad autovideosink
        try:
            if USE_KMS and player["pipeline"] and pipeline_has_kmssink(player["pipeline"]):
                print("[PLAYER] KMS errore/permessi: fallback ad autovideosink", flush=True)
                # Disattiva KMS e ricrea pipeline sullo stesso media
                globals()["USE_KMS"] = False
                if player["pipeline"]:
                    player["pipeline"].set_state(Gst.State.NULL)
                # Ricrea pipeline e riparti
                def restart_after_fallback():
                    try:
                        ensure_pipeline()
                        if player["vb"]:
                            player["vb"].set_property("brightness", -1.0)
                        player["pipeline"].set_state(Gst.State.PLAYING)
                        player["state"] = "playing"
                        print("[PLAYER] Ripartenza con autovideosink effettuata", flush=True)
                    except Exception as fe:
                        print(f"[PLAYER] Fallback start failed: {fe}", flush=True)
                GLib.idle_add(restart_after_fallback)
                return
        except Exception as _:
            pass
        if player["pipeline"]:
            stop_play()
        else:
            player["state"] = "error"
        if not splash["active"]:
            show_splash_until_play()
    elif t == Gst.MessageType.WARNING:
        warn, debug = msg.parse_warning()
        print(f"[PLAYER] GST WARNING: {warn}", flush=True)
        print(f"[PLAYER] Debug info: {debug}", flush=True)
    elif t == Gst.MessageType.INFO:
        info, debug = msg.parse_info()
        print(f"[PLAYER] GST INFO: {info}", flush=True)

def ensure_pipeline():
    if player["pipeline"]:
        return
    print(f"[PLAYER] Creo pipeline per: {VIDEO_PATH}", flush=True)
    p, vb, af = build_player_pipeline(VIDEO_PATH)
    player["pipeline"] = p
    player["vb"] = vb
    player["alpha"] = af
    print("[PLAYER] Pipeline creata", flush=True)

def validate_media_file(path: Path) -> bool:
    if not path.exists():
        print(f"[PLAYER] ERRORE: File non trovato: {path}", flush=True); return False
    try:
        with open(path, 'rb') as f:
            header = f.read(16)
        if len(header) < 12:
            print(f"[PLAYER] ERRORE: File troppo corto: {path}", flush=True); return False
        # MP4: bytes 4-8 = 'ftyp'
        if header[4:8] == b'ftyp':
            return True
        # Matroska
        if header.startswith(b'\x1a\x45\xdf\xa3'):
            return True
        # AVI: 'RIFF....AVI '
        if header.startswith(b'RIFF') and header[8:12] == b'AVI ':
            return True
        print(f"[PLAYER] ERRORE: Header non riconosciuto ({header[:8].hex()}) per {path}", flush=True)
        return False
    except Exception as e:
        print(f"[PLAYER] ERRORE lettura header {path}: {e}", flush=True)
        return False

def start_play_with_path(path: str):
    global VIDEO_PATH
    VIDEO_PATH = path
    start_play()

def start_play(fade_in_seconds: float = 0.5):
    print(f"[PLAYER] Avvio riproduzione: {VIDEO_PATH}", flush=True)
    media_path = Path(VIDEO_PATH)
    if not validate_media_file(media_path):
        player["state"] = "error"; return
    _reset_visual_effects_before_play()
    if not adopt_preloaded(VIDEO_PATH):
        ensure_pipeline()
        # Inizializza a nero: preferisci alpha se disponibile, altrimenti brightness
        if player["alpha"]:
            try: player["alpha"].set_property("alpha", 0.0)
            except Exception: pass
        if player["vb"]:
            try: player["vb"].set_property("brightness", -1.0)
            except Exception: pass
        if splash["active"]:
            hide_splash()
        player["pipeline"].set_state(Gst.State.PLAYING)
        player["state"] = "playing"
        if playlist["items"]:
            schedule_preload()
        print("[PLAYER] Riproduzione avviata (nuova pipeline)", flush=True)
    else:
        print("[PLAYER] Riproduzione avviata (pipeline precaricata)", flush=True)
    # Fade-in automatico
    if fade_in_seconds and fade_in_seconds > 0:
        if player["alpha"]:
            fade_opacity_to(1.0, fade_in_seconds, start_from=0.0)
        elif player["vb"]:
            fade_to(0.0, fade_in_seconds, start_from=-1.0)

def pause_play():
    if player["pipeline"]:
        player["pipeline"].set_state(Gst.State.PAUSED)
        player["state"] = "paused"

def resume_play():
    if player["pipeline"]:
        player["pipeline"].set_state(Gst.State.PLAYING)
        player["state"] = "playing"

def stop_play():
    if player["pipeline"]:
        player["pipeline"].set_state(Gst.State.NULL)
        player["state"] = "stopped"
        player["pipeline"] = None
    player["vb"] = None
    player["alpha"] = None

def set_loop(on: bool):
    player["loop"] = bool(on)

def fade_to(target: float, duration_s: float = 1.0, on_complete=None, start_from: float | None = None):
    """Esegue fade non bloccante sul brightness.
    target: valore finale (-1..1)
    duration_s: durata in secondi
    on_complete: callback chiamata al termine
    start_from: se definito forza brightness iniziale prima di iniziare
    """
    global fade_seq
    vb = player["vb"]
    if not vb or duration_s <= 0:
        if vb:
            vb.set_property("brightness", target)
        if on_complete:
            GLib.idle_add(on_complete)
        return
    if start_from is not None:
        vb.set_property("brightness", start_from)
    cur = vb.get_property("brightness")
    steps = max(1, int(duration_s / (FADE_INTERVAL_MS / 1000.0)))
    step_val = (target - cur) / steps
    fade_seq += 1
    my_seq = fade_seq

    def stepper(i=[0], val=[cur]):
        if my_seq != fade_seq:
            return False  # Cancellato da nuovo fade
        if not player["vb"]:
            return False
        val[0] += step_val
        final = (i[0] + 1) >= steps
        vb.set_property("brightness", max(-1.0, min(1.0, target if final else val[0])))
        i[0] += 1
        if final:
            if on_complete:
                GLib.idle_add(on_complete)
            return False
        return True

    GLib.timeout_add(FADE_INTERVAL_MS, stepper)

def fade_opacity_to(target: float, duration_s: float = 1.0, on_complete=None, start_from: float | None = None):
    """Fade sull'opacità (elemento alpha), range 0..1. Fallback: no-op se alpha mancante."""
    global fade_seq
    af = player["alpha"]
    if not af or duration_s <= 0:
        if af:
            af.set_property("alpha", max(0.0, min(1.0, target)))
        if on_complete:
            GLib.idle_add(on_complete)
        return
    if start_from is not None:
        af.set_property("alpha", start_from)
    try:
        cur = float(af.get_property("alpha"))
    except Exception:
        cur = 1.0
    steps = max(1, int(duration_s / (FADE_INTERVAL_MS / 1000.0)))
    step_val = (target - cur) / steps
    fade_seq += 1
    my_seq = fade_seq

    def stepper(i=[0], val=[cur]):
        if my_seq != fade_seq:
            return False
        if not player["alpha"]:
            return False
        val[0] += step_val
        final = (i[0] + 1) >= steps
        af.set_property("alpha", max(0.0, min(1.0, target if final else val[0])))
        i[0] += 1
        if final:
            if on_complete:
                GLib.idle_add(on_complete)
            return False
        return True

    GLib.timeout_add(FADE_INTERVAL_MS, stepper)

def ping_on_player(duration_ms: int = 120):
    """Effetto lampo veloce sul player: preferisci alpha (black flash) o brightness boost."""
    try:
        # Preferisci saturazione alta (flash "bianco")
        if player["vb"] and player["vb"] is not None:
            vb = player["vb"]
            cur_sat = None
            try:
                cur_sat = float(vb.get_property("saturation"))
            except Exception:
                cur_sat = None
            if cur_sat is not None:
                vb.set_property("saturation", 2.0)
                def restore():
                    try:
                        vb.set_property("saturation", cur_sat)
                    except Exception:
                        pass
                    return False
                GLib.timeout_add(max(10, duration_ms), restore)
                return True
        if player["alpha"]:
            af = player["alpha"]
            cur = float(af.get_property("alpha"))
            af.set_property("alpha", 0.0)
            def restore():
                try:
                    af.set_property("alpha", cur)
                except Exception:
                    pass
                return False
            GLib.timeout_add(max(10, duration_ms), restore)
            return True
        elif player["vb"]:
            vb = player["vb"]
            cur = float(vb.get_property("brightness"))
            boost = max(-1.0, min(1.0, cur + 0.6))
            vb.set_property("brightness", boost)
            def restore():
                try:
                    vb.set_property("brightness", cur)
                except Exception:
                    pass
                return False
            GLib.timeout_add(max(10, duration_ms), restore)
            return True
    except Exception:
        return False
    return False

def push_white_splash_frame(appsrc):
    """Pusha un frame di splash completamente bianco (flash)."""
    img = Image.new("RGB", (TARGET_WIDTH, TARGET_HEIGHT), (255, 255, 255))
    buf = Gst.Buffer.new_allocate(None, TARGET_WIDTH * TARGET_HEIGHT * 3, None)
    buf.fill(0, img.tobytes())
    now = int(time.time() * Gst.SECOND)
    buf.pts = buf.dts = now
    appsrc.emit("push-buffer", buf)

def ping_on_splash(duration_ms: int = 120):
    """Effetto lampo sempre visibile: frame bianco temporaneo, poi ripristino splash."""
    try:
        if not splash.get("active"):
            return False
        appsrc = splash.get("src")
        vb = splash.get("vb")
        if not appsrc:
            return False
        # 1) Boost visivo immediato sul videobalance (più affidabile del solo frame)
        restored = {"done": False}
        cur_bri = None; cur_sat = None
        if vb:
            try:
                cur_bri = float(vb.get_property("brightness"))
            except Exception:
                cur_bri = None
            try:
                cur_sat = float(vb.get_property("saturation"))
            except Exception:
                cur_sat = None
            try:
                if cur_bri is not None:
                    vb.set_property("brightness", 1.0)
                if cur_sat is not None:
                    vb.set_property("saturation", 2.0)
            except Exception:
                pass
        # 2) Inoltre pusha un frame bianco
        GLib.idle_add(push_white_splash_frame, appsrc)
        # Restore dopo la durata
        def restore():
            if restored["done"]:
                return False
            restored["done"] = True
            try:
                # Ripristina frame splash
                push_splash_frame(appsrc)
            except Exception:
                pass
            # Ripristina proprietà vb
            try:
                if vb and (cur_bri is not None):
                    vb.set_property("brightness", cur_bri)
                if vb and (cur_sat is not None):
                    vb.set_property("saturation", cur_sat)
            except Exception:
                pass
            return False
        GLib.timeout_add(max(20, duration_ms), restore)
        return True
    except Exception:
        return False

def _reset_visual_effects_before_play():
    """Ripristina valori standard per evitare che un ping residuo alteri il contenuto."""
    try:
        if player.get("vb"):
            try:
                player["vb"].set_property("saturation", 1.0)
            except Exception:
                pass
    except Exception:
        pass

@app.post("/ping")
def api_ping(duration_ms: int = Query(200)):
    """Risponde subito e provoca un lampo visivo rapido sul device."""
    scheduled = False
    if player.get("pipeline"):
        scheduled = ping_on_player(duration_ms)
    elif splash.get("active"):
        scheduled = ping_on_splash(duration_ms)
    return {"ok": True, "scheduled": bool(scheduled), "state": player.get("state")}

@app.get("/ping")
def api_ping_get(duration_ms: int = Query(200)):
    return api_ping(duration_ms)

def schedule_preload():
    """Precarica la prossima entry playlist in stato PAUSED per ridurre il gap."""
    if not playlist["items"]:
        return
    if playlist["index"] < 0:
        return
    # Calcola prossimo indice
    next_index = playlist["index"] + 1
    if next_index >= len(playlist["items"]):
        if playlist["loop"]:
            next_index = 0
        else:
            return
    next_path = playlist["items"][next_index]
    if preloaded["path"] == next_path:
        return  # già pronto
    # Libera eventuale preload precedente
    if preloaded["pipeline"]:
        try:
            preloaded["pipeline"].set_state(Gst.State.NULL)
        except Exception:
            pass
        preloaded.update({"path": None, "pipeline": None, "vb": None})
    try:
        print(f"[PRELOAD] Precarico: {next_path}", flush=True)
        p, vb, af = build_player_pipeline(next_path)
        # Stato PAUSED per preroll (veloce start successivo)
        p.set_state(Gst.State.PAUSED)
        preloaded.update({"path": next_path, "pipeline": p, "vb": vb, "alpha": af})
    except Exception as e:
        print(f"[PRELOAD] Errore preload {next_path}: {e}", flush=True)

def adopt_preloaded(path: str) -> bool:
    """Se esiste pipeline precaricata per path la adotta e ritorna True."""
    if preloaded["path"] != path:
        return False
    # Spegni pipeline corrente
    if player["pipeline"]:
        try:
            player["pipeline"].set_state(Gst.State.NULL)
        except Exception:
            pass
    player["pipeline"] = preloaded["pipeline"]
    player["vb"] = preloaded["vb"]
    player["alpha"] = preloaded.get("alpha")
    preloaded.update({"path": None, "pipeline": None, "vb": None, "alpha": None})
    # Inizializza nero
    _reset_visual_effects_before_play()
    if player["alpha"]:
        try: player["alpha"].set_property("alpha", 0.0)
        except Exception: pass
    if player["vb"]:
        try: player["vb"].set_property("brightness", -1.0)
        except Exception: pass
    player["pipeline"].set_state(Gst.State.PLAYING)
    player["state"] = "playing"
    if splash["active"]:
        hide_splash()
    print(f"[PRELOAD] Adottata pipeline precaricata: {path}", flush=True)
    # Pianifica preload successivo
    schedule_preload()
    # Fade-in
    if player["alpha"]:
        fade_opacity_to(1.0, 0.5, start_from=0.0)
    elif player["vb"]:
        fade_to(0.0, 0.5, start_from=-1.0)
    return True

# ---------- Update helpers ----------
def download_to(path: Path, url: str, report=None):
    req = Request(url, headers={"User-Agent": "headless-player"})
    tmp_path = path.with_suffix(path.suffix + ".part")
    with urlopen(req, timeout=30) as r, open(tmp_path, "wb") as f:
        total = int(r.headers.get("Content-Length", 0))
        got = 0
        while True:
            chunk = r.read(8192)
            if not chunk:
                break
            f.write(chunk)
            got += len(chunk)
            if report:
                report(got, total)
    try:
        os.replace(tmp_path, path)
    except PermissionError as e:
        # Ritenta dopo chmod se possibile
        try:
            os.chmod(path, 0o644)
            os.replace(tmp_path, path)
        except Exception:
            raise e

def apply_update(archive: Path):
    tmp = APP_DIR / "release_tmp"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True, exist_ok=True)

    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            z.extractall(tmp)
    else:
        try:
            with tarfile.open(archive) as t:
                t.extractall(tmp)
        except Exception:
            raise RuntimeError("Formato update non supportato (zip/tar.*)")

    for root, dirs, files in os.walk(tmp):
        rel = Path(root).relative_to(tmp)
        dest = APP_DIR / rel
        dest.mkdir(parents=True, exist_ok=True)
        for name in files:
            if str((rel / name)).startswith("media/"):
                continue
            shutil.copy2(Path(root)/name, dest)

    shutil.rmtree(tmp)

# ---------- FastAPI ----------
@app.on_event("startup")
def on_start():
    print("[STARTUP] Avvio applicazione", flush=True)
    def start_glib_and_splash():
        print("[STARTUP] Avvio main loop GLib", flush=True)
        # Avvia il main loop in un thread separato
        threading.Thread(target=main_loop.run, daemon=True).start()
        # Aspetta un po' che il main loop si avvii
        time.sleep(0.5)
        print("[STARTUP] Main loop avviato, mostro splash", flush=True)
        show_splash_until_play()  # Cambiato qui
    
    threading.Thread(target=start_glib_and_splash, daemon=True).start()

@app.get("/healthz")
def healthz():
    return {"status": "ok", "state": player["state"], "version": VERSION, "ip": get_ip()}

@app.get("/status")
def status():
    return {
        "version_current": VERSION,
        "version_available": current_update["available"],
        "player_state": player["state"],
        "splash_active": splash["active"],
        "update_status": current_update["status"],
    "update_progress": current_update.get("progress"),
    "update_error": current_update.get("error"),
    "update_bytes_done": current_update.get("bytes_done"),
    "update_bytes_total": current_update.get("bytes_total"),
        "last_logs": current_update["log"][-10:],
    "maintenance_status": maintenance["status"],
    "maintenance_last_logs": maintenance["log"][-10:],
    }

@app.post("/hide_splash")
def api_hide_splash():
    if splash["active"]:
        hide_splash()
        return {"ok": True, "message": "Splash nascosto"}
    else:
        return {"ok": True, "message": "Splash già nascosto"}

@app.post("/porcoddue")
def api_porcoddue():
    os._exit(1)

@app.post("/shutdown")
def api_shutdown():
    """Chiude l'applicazione in modo pulito."""
    print("[SHUTDOWN] Chiusura applicazione su richiesta", flush=True)
    GLib.idle_add(main_loop.quit)
    time.sleep(1)
    os.system("sudo shutdown -h now ")
    os.system("sudo poweroff")
    subprocess.run(["sudo", "poweroff"])



@app.post("/play")
def api_play(
    path: Optional[str] = Body(None, embed=True),
    filename: Optional[str] = Body(None, embed=True),
    loop: Optional[bool] = Body(None, embed=True),
    hide_splash_first: bool = Body(True, embed=True),
    fade_in_seconds: float = Body(0.5, embed=True),
    fade_out_seconds: Optional[float] = Body(None, embed=True),
    # Fallback da query string (se body vuoto)
    path_q: Optional[str] = Query(None),
    filename_q: Optional[str] = Query(None),
    loop_q: Optional[int] = Query(None),
):
    """Avvia la riproduzione.
    Parametri accettati (JSON body):
      - path: percorso assoluto (deve stare dentro la media dir o essere file leggibile)
      - filename: nome di un file dentro media/ (esclusivo con path)
      - loop: abilita/disabilita loop (facoltativo)
      - hide_splash_first: default True, nasconde lo splash se attivo
    Precedenza: path > filename > default (VIDEO_PATH attuale).
    """
    global VIDEO_PATH

    chosen = None
    # Se non arrivano dal body, usa i parametri query
    path = path or path_q
    filename = filename or filename_q
    if loop is None and loop_q is not None:
        loop = bool(loop_q)
    if path and filename:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Usa solo uno tra 'path' e 'filename'"})

    if path:
        p = Path(path)
        if not p.exists():
            return JSONResponse(status_code=404, content={"ok": False, "error": f"File non trovato: {path}"})
        # Non forzare che sia in media, ma avvisa se fuori
        if not str(p).startswith(str(MEDIA_DIR)):
            print(f"[PLAY] WARNING: file fuori da media/: {p}", flush=True)
        chosen = str(p)
    elif filename:
        p = MEDIA_DIR / filename
        if not p.exists():
            # Fallback intelligente: se filename non esiste (es. vecchio default clip.mp4), prova a scansionare media/
            print(f"[PLAY] '{filename}' non trovato in media/. Provo fallback su altri file presenti…", flush=True)
            items = []
            for fp in sorted(MEDIA_DIR.iterdir()):
                if fp.is_file() and validate_media_file(fp):
                    items.append(str(fp))
            if items:
                playlist["items"] = items
                playlist["index"] = 0
                chosen = items[0]
                print(f"[PLAY] Fallback: avvio {chosen}", flush=True)
            else:
                return JSONResponse(status_code=404, content={"ok": False, "error": f"File non trovato in media/: {filename}"})
        else:
            chosen = str(p)
    else:
        # fallback: playlist se esiste; altrimenti scansione rapida di media/
        if playlist["items"]:
            if 0 <= playlist["index"] < len(playlist["items"]):
                chosen = playlist["items"][playlist["index"]]
            else:
                playlist["index"] = 0
                chosen = playlist["items"][0]
        else:
            items = []
            for p in sorted(MEDIA_DIR.iterdir()):
                if p.is_file() and validate_media_file(p):
                    items.append(str(p))
            if items:
                playlist["items"] = items
                playlist["index"] = 0
                chosen = items[0]
            elif Path(VIDEO_PATH).exists():
                chosen = VIDEO_PATH
            else:
                return JSONResponse(status_code=404, content={"ok": False, "error": "Nessun file in media/: carica un video o specifica filename"})

    if chosen:
        # Stop pipeline corrente se cambia file
        if chosen != VIDEO_PATH:
            stop_play()
        VIDEO_PATH = chosen
        # Se il file è in playlist, aggiorna l'indice corrente alla sua posizione
        try:
            if playlist["items"]:
                if chosen in playlist["items"]:
                    playlist["index"] = playlist["items"].index(chosen)
                else:
                    # se non è presente, resetta index coerentemente
                    playlist["index"] = -1
        except Exception:
            pass

    # Non toccare qui lo splash o la pipeline: ci pensa start_play()

    if loop is not None:
        set_loop(loop)
    def do_start():
        start_play(fade_in_seconds)
    if fade_out_seconds and player["pipeline"] and chosen:
        fade_opacity_to(0.0, max(0.05, fade_out_seconds), on_complete=do_start)
    else:
        fade_to(-1.0, max(0.05, fade_out_seconds), on_complete=do_start)
    return {"ok": True, "playing": VIDEO_PATH, "loop": player["loop"], "splash_active": splash["active"], "fade_in": fade_in_seconds}

@app.get("/play")
def api_play_get(
    path: Optional[str] = Query(None),
    filename: Optional[str] = Query(None),
    loop: Optional[int] = Query(None),
    fade_in_seconds: float = Query(0.5),
    fade_out_seconds: Optional[float] = Query(None),
):
    loop_bool = (loop == 1) if loop is not None else None
    # Riutilizza la stessa logica del POST
    return api_play(path, filename, loop_bool, True, fade_in_seconds, fade_out_seconds, None, None, None)

@app.post("/fade_out_current")
def api_fade_out_current(seconds: float = Body(1.0, embed=True)):
    if player["alpha"]:
        fade_opacity_to(0.0, seconds)
    else:
        fade_to(-1.0, seconds)
    return {"ok": True}

@app.post("/pause")
def api_pause():
    pause_play(); return {"ok": True}

@app.post("/resume")
def api_resume():
    resume_play(); return {"ok": True}

@app.post("/loop")
def api_loop(on: int = Query(1)):
    set_loop(on == 1); return {"ok": True, "loop": player["loop"]}

@app.post("/fade_in")
def api_fade_in(seconds: float = Query(1.0)):
    if player["alpha"]:
        fade_opacity_to(1.0, seconds)
    else:
        fade_to(0.0, seconds)
    return {"ok": True}

@app.post("/fade_out")
def api_fade_out(seconds: float = Query(1.0)):
    if player["alpha"]:
        fade_opacity_to(0.0, seconds)
    else:
        fade_to(-1.0, seconds)
    return {"ok": True}

@app.get("/media")
def list_media():
    """Elenca i file nella directory media con informazioni dettagliate"""
    files = []
    try:
        for file_path in MEDIA_DIR.iterdir():
            if file_path.is_file():
                stat = file_path.stat()
                
                # Leggi i primi bytes per determinare il tipo
                file_type = "unknown"
                with open(file_path, 'rb') as f:
                    header = f.read(16)
                    if header[4:8] == b'ftyp':
                        file_type = "mp4"
                    elif header.startswith(b'<!DOCTYPE') or header.startswith(b'<html'):
                        file_type = "html"
                    elif header.startswith(b'\x1a\x45\xdf\xa3'):
                        file_type = "mkv"
                    elif header.startswith(b'RIFF') and header[8:12] == b'AVI ':
                        file_type = "avi"
                
                files.append({
                    "name": file_path.name,
                    "path": str(file_path),
                    "size": stat.st_size,
                    "modified": stat.st_mtime,
                    "type": file_type,
                    "header": header[:8].hex() if len(header) >= 8 else ""
                })
        
        return {"ok": True, "files": files}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})

@app.post("/media/clear")
def media_clear(confirm: int = Query(0)):
    """Cancella TUTTI i contenuti nella directory media del device.
    Per sicurezza richiede confirm=1 come query (es: POST /media/clear?confirm=1).
    """
    if confirm != 1:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Conferma mancante: usa ?confirm=1"})
    removed = 0
    errors = []
    try:
        for entry in MEDIA_DIR.iterdir():
            try:
                if entry.is_file() or entry.is_symlink():
                    entry.unlink(missing_ok=True); removed += 1
                elif entry.is_dir():
                    shutil.rmtree(entry, ignore_errors=True); removed += 1
            except Exception as e:
                errors.append(f"{entry.name}: {e}")
        return {"ok": True, "removed": removed, "errors": errors}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})

@app.get("/media/clear")
def media_clear_get(confirm: int = Query(0)):
    """Alias GET per compatibilità: richiede comunque confirm=1."""
    return media_clear(confirm)

@app.post("/settings/reload")
def api_settings_reload(data: Optional[dict] = Body(None)):
    """Aggiorna impostazioni runtime e ricrea la pipeline e lo splash se attivo.
    Accetta JSON tipo: {"USE_KMS": false, "USE_HW_DECODER": true, "TARGET_WIDTH": 1280, ... , "restart_play": true, "SPLASH_BLACK": false}
    """
    global USE_KMS, USE_HW_DECODER, TARGET_WIDTH, TARGET_HEIGHT, TARGET_FPS, SPLASH_BLACK
    data = data or {}
    changes = {}
    if "USE_KMS" in data:
        USE_KMS = bool(data["USE_KMS"]); changes["USE_KMS"] = USE_KMS
    if "USE_HW_DECODER" in data:
        USE_HW_DECODER = bool(data["USE_HW_DECODER"]); changes["USE_HW_DECODER"] = USE_HW_DECODER
    if "TARGET_WIDTH" in data:
        TARGET_WIDTH = int(data["TARGET_WIDTH"]); changes["TARGET_WIDTH"] = TARGET_WIDTH
    if "TARGET_HEIGHT" in data:
        TARGET_HEIGHT = int(data["TARGET_HEIGHT"]); changes["TARGET_HEIGHT"] = TARGET_HEIGHT
    if "TARGET_FPS" in data:
        TARGET_FPS = str(data["TARGET_FPS"]); changes["TARGET_FPS"] = TARGET_FPS
    if "SPLASH_BLACK" in data:
        SPLASH_BLACK = bool(data["SPLASH_BLACK"]); changes["SPLASH_BLACK"] = SPLASH_BLACK

    restart_play = bool(data.get("restart_play", True))

    # Ricrea pipeline del player
    was_playing = (player["state"] == "playing")
    if player["pipeline"]:
        try:
            player["pipeline"].set_state(Gst.State.NULL)
        except Exception:
            pass
        player["pipeline"] = None; player["vb"] = None
    # Pulisci preload
    preloaded.update({"path": None, "pipeline": None, "vb": None})

    # Ricrea splash con nuovo sink/impostazioni se attivo
    splash_was_active = splash["active"]
    if splash_was_active:
        try:
            hide_splash()
        except Exception:
            pass
        show_splash_until_play()

    if was_playing and restart_play:
        ensure_pipeline();
        if player["vb"]:
            player["vb"].set_property("brightness", -1.0)
        player["pipeline"].set_state(Gst.State.PLAYING)
        player["state"] = "playing"
    else:
        player["state"] = "stopped"
    return {"ok": True, "changes": changes, "was_playing": was_playing, "splash_recreated": splash_was_active, "state": player["state"]}

@app.get("/settings/reload")
def api_settings_reload_get(
    USE_KMS: Optional[int] = None,
    USE_HW_DECODER: Optional[int] = None,
    TARGET_WIDTH: Optional[int] = None,
    TARGET_HEIGHT: Optional[int] = None,
    TARGET_FPS: Optional[str] = None,
    SPLASH_BLACK: Optional[int] = None,
    restart_play: int = 1,
):
    data = {}
    if USE_KMS is not None: data["USE_KMS"] = bool(USE_KMS)
    if USE_HW_DECODER is not None: data["USE_HW_DECODER"] = bool(USE_HW_DECODER)
    if TARGET_WIDTH is not None: data["TARGET_WIDTH"] = int(TARGET_WIDTH)
    if TARGET_HEIGHT is not None: data["TARGET_HEIGHT"] = int(TARGET_HEIGHT)
    if TARGET_FPS is not None: data["TARGET_FPS"] = str(TARGET_FPS)
    if SPLASH_BLACK is not None: data["SPLASH_BLACK"] = bool(SPLASH_BLACK)
    data["restart_play"] = bool(restart_play)
    return api_settings_reload(data)

def _handle_download_asset(url: str, filename: Optional[str] = None):
    if not url:
        return JSONResponse(status_code=422, content={"ok": False, "error": "Campo 'url' mancante"})
    MEDIA_DIR.mkdir(exist_ok=True)
    name = (filename or url.split("/")[-1] or "asset.bin").strip()
    dest = MEDIA_DIR / name

    print(f"[DOWNLOAD] Scarico asset da: {url} -> {dest.name}", flush=True)

    def rep(got, total):
        if total > 0:
            pct = int(got * 100 / total)
            if pct % 20 == 0:
                print(f"[DOWNLOAD] Progresso: {pct}% ({got}/{total} bytes)", flush=True)

    try:
        download_to(dest, url, report=rep)

        # Controlla il file scaricato
        file_size = dest.stat().st_size
        print(f"[DOWNLOAD] File scaricato: {dest} ({file_size} bytes)", flush=True)

        # Controlla i primi bytes per identificare il tipo di file
        with open(dest, 'rb') as f:
            header = f.read(16)
            print(f"[DOWNLOAD] Header file: {header[:8].hex()}", flush=True)

            # Controlla se è un file MP4 valido
            if len(header) >= 8 and header[4:8] == b'ftyp':
                print("[DOWNLOAD] File riconosciuto come MP4", flush=True)
            elif len(header) >= 4 and (header[:4] == b'\x00\x00\x00\x20' or header[:4] == b'\x00\x00\x00\x18'):
                print("[DOWNLOAD] Possibile file MP4 con header diverso", flush=True)
            else:
                print(f"[DOWNLOAD] ATTENZIONE: File non riconosciuto come MP4. Header: {header[:8]}", flush=True)
                # Controlla se è HTML (errore 404/500)
                if header.startswith(b'<!DOCTYPE') or header.startswith(b'<html'):
                    print("[DOWNLOAD] ERRORE: Il server ha restituito HTML invece di un video!", flush=True)

        return {"ok": True, "stored": str(dest), "size": file_size}
    except Exception as e:
        print(f"[DOWNLOAD] ERRORE: {e}", flush=True)
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})

@app.post("/download_asset")
def download_asset(payload: dict = Body(...)):
    # Estrai parametri dal JSON body
    if not isinstance(payload, dict):
        return JSONResponse(status_code=400, content={"ok": False, "error": "Body JSON richiesto"})
    url = payload.get("url")
    filename = payload.get("filename")
    return _handle_download_asset(url, filename)

@app.get("/download_asset")
def download_asset_get(url: str, filename: Optional[str] = None):
    """Alias GET per compatibilità: /download_asset?url=...&filename=..."""
    return _handle_download_asset(url, filename)

@app.get("/network/ethernet/status")
def ethernet_status():
    """Ritorna stato connessioni ethernet e indirizzi IP v4."""
    info = {"nmcli": None, "ip_addr": None}
    try:
        out = subprocess.check_output(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE,IP4.ADDRESS", "connection", "show"], text=True)
        info["nmcli"] = out.strip().splitlines()
    except Exception as e:
        info["nmcli"] = [f"errore: {e}"]
    try:
        out = subprocess.check_output(["ip", "-4", "addr", "show"], text=True)
        info["ip_addr"] = out.strip().splitlines()
    except Exception as e:
        info["ip_addr"] = [f"errore: {e}"]
    return {"ok": True, "info": info}

@app.post("/network/ethernet/config")
def ethernet_config(data: dict = Body(...)):
    """Configura IP statico su connessione ethernet principale via nmcli.
    Body: {"ip_cidr": "192.168.1.50/24", "gateway": "", "dns": ""}
    """
    if not isinstance(data, dict):
        return JSONResponse(status_code=400, content={"ok": False, "error": "Body JSON richiesto"})
    ip_cidr = data.get("ip_cidr")
    gateway = data.get("gateway", "")
    dns = data.get("dns", "")
    if not ip_cidr:
        return JSONResponse(status_code=422, content={"ok": False, "error": "Campo 'ip_cidr' mancante"})
    log = []
    try:
        # Trova prima connessione ethernet
        cmd_find = "nmcli -t -f NAME,TYPE connection show | awk -F: '$2==\"ethernet\"{print $1; exit}'"
        p = subprocess.Popen(["bash", "-lc", cmd_find], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate(timeout=5)
        if p.returncode != 0:
            return JSONResponse(status_code=500, content={"ok": False, "error": f"nmcli find failed: {err.strip()}"})
        eth_con = out.strip() or ""
        if not eth_con:
            return JSONResponse(status_code=404, content={"ok": False, "error": "Nessuna connessione ethernet trovata"})
        log.append(f"Connessione ethernet: {eth_con}")
        # Applica configurazione con sudo -n
        cmds = [
            f"nmcli con mod '{eth_con}' ipv4.method manual ipv4.addresses '{ip_cidr}'",
            f"nmcli con mod '{eth_con}' ipv4.gateway '{gateway}'",
            f"nmcli con mod '{eth_con}' ipv4.dns '{dns}'",
            f"nmcli con up '{eth_con}'"
        ]
        for c in cmds:
            rc = subprocess.call(["sudo", "-n", "bash", "-lc", c])
            log.append(f"$ {c} -> rc={rc}")
            if rc != 0:
                return JSONResponse(status_code=500, content={"ok": False, "error": f"Comando fallito: {c}", "log": log})
        return {"ok": True, "log": log}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e), "log": log})

def _start_download_update(url: str, version: Optional[str], callback_url: Optional[str], start_at: Optional[float] = None):
    # Evita doppio avvio se già in corso
    if current_update["status"] == "downloading":
        return {"ok": True, "status": "already-downloading", "progress": current_update.get("progress")}

    current_update["available"] = version or "unknown"
    current_update["callback_url"] = callback_url
    current_update["progress"] = 0
    current_update["error"] = None
    current_update["log"] = current_update["log"][-100:]
    current_update["status"] = "downloading"
    current_update["bytes_done"] = 0
    current_update["bytes_total"] = 0
    dest = APP_DIR / "update_pkg.bin"

    log_update(f"Inizio download update: url={url} version={current_update['available']}")

    def worker():
        try:
            # Attendi fino a start_at se fornito
            if start_at:
                delay = max(0.0, float(start_at) - time.time())
                if delay > 0:
                    log_update(f"Attendo {delay:.2f}s per start_at")
                    time.sleep(delay)
            def rep(got, total):
                current_update["bytes_done"] = got
                current_update["bytes_total"] = total
                if total:
                    pct = int(got * 100 / total)
                    if pct != current_update.get("progress"):
                        current_update["progress"] = pct
                        if pct % 10 == 0:
                            log_update(f"Download {pct}% ({got}/{total} bytes)")
            download_to(dest, url, report=rep)

            # Verifica header file scaricato per intercettare HTML (404/errore)
            with open(dest, "rb") as f:
                header = f.read(64)
            if header.startswith(b"<!DOCTYPE") or header.startswith(b"<html"):
                raise RuntimeError("Il server ha restituito HTML (probabile 404/errore) non un archivio update")

            current_update["progress"] = 100
            log_update("Download completato")
            current_update["status"] = "downloaded"
        except Exception as e:
            current_update["status"] = "error"
            current_update["error"] = str(e)
            log_update(f"Errore download: {e}")

    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, "status": "started", "progress": 0}

@app.post("/download_update")
def download_update_post(payload: dict = Body(...)):
    """Avvia il download via POST JSON: {"url": ..., "version": ..., "callback_url": ...}"""
    url = payload.get("url") if isinstance(payload, dict) else None
    version = payload.get("version") if isinstance(payload, dict) else None
    callback_url = payload.get("callback_url") if isinstance(payload, dict) else None
    start_at = payload.get("start_at") if isinstance(payload, dict) else None
    if not url:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Campo 'url' mancante"})
    return _start_download_update(url, version, callback_url, start_at)

@app.get("/download_update")
def download_update_get(url: str, version: Optional[str] = None, callback_url: Optional[str] = None, start_at: Optional[float] = None):
    """Avvia il download via GET con query params (?url=...&version=...)."""
    if not url:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Parametro 'url' richiesto"})
    return _start_download_update(url, version, callback_url, start_at)

@app.post("/media/playlist")
def api_playlist(loop: bool = Body(True, embed=True)):
    """Crea una playlist con tutti i file validi dentro media/ e avvia dal primo.
    Parametri:
      - loop (bool): se True la playlist riparte da capo.
    Filtra solo file video riconosciuti da validate_media_file.
    """
    items = []
    scan = []
    for p in sorted(MEDIA_DIR.iterdir()):
        if not p.is_file():
            continue
        # esegui check header
        valid = validate_media_file(p)
        # determina tipo
        ftype = "unknown"; header_hex = ""
        try:
            with open(p, 'rb') as fh:
                header = fh.read(16)
                header_hex = header[:8].hex() if len(header) >= 8 else ""
                if len(header) >= 8 and header[4:8] == b'ftyp':
                    ftype = "mp4"
                elif header.startswith(b'\x1a\x45\xdf\xa3'):
                    ftype = "mkv"
                elif len(header) >= 12 and header.startswith(b'RIFF') and header[8:12] == b'AVI ':
                    ftype = "avi"
                elif header.startswith(b'<!DOCTYPE') or header.startswith(b'<html'):
                    ftype = "html"
        except Exception:
            pass
        scan.append({"path": str(p), "valid": valid, "type": ftype, "header": header_hex})
        if valid:
            items.append(str(p))
        else:
            print(f"[PLAYLIST] Ignoro (non valido): {p.name}", flush=True)
    if not items:
        return JSONResponse(status_code=404, content={"ok": False, "error": "Nessun file video valido in media/"})
    playlist["items"] = items
    playlist["index"] = 0
    playlist["loop"] = loop
    print(f"[PLAYLIST] Creata playlist con {len(items)} elementi (loop={loop})", flush=True)
    stop_play()
    start_play_with_path(items[0])
    return {"ok": True, "count": len(items), "current": items[0], "loop": loop, "items": items, "scan": scan}

@app.get("/playlist/status")
def api_playlist_status():
    return {
        "ok": True,
        "items": playlist["items"],
        "index": playlist["index"],
        "current": playlist["items"][playlist["index"]] if (playlist["items"] and 0 <= playlist["index"] < len(playlist["items"])) else None,
        "loop": playlist["loop"],
    }

@app.post("/playlist/next")
def api_playlist_next():
    if not playlist["items"]:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Playlist vuota"})
    if playlist["index"] < 0:
        playlist["index"] = 0
    next_i = playlist["index"] + 1
    if next_i >= len(playlist["items"]):
        if playlist["loop"]:
            next_i = 0
        else:
            return JSONResponse(status_code=400, content={"ok": False, "error": "Fine playlist"})
    playlist["index"] = next_i
    next_path = playlist["items"][next_i]
    print(f"[PLAYLIST] NEXT -> index={next_i} file={next_path}", flush=True)
    start_play_with_path(next_path)
    return {"ok": True, "current": next_path, "index": next_i}

@app.post("/playlist/prev")
def api_playlist_prev():
    if not playlist["items"]:
        return JSONResponse(status_code=400, content={"ok": False, "error": "Playlist vuota"})
    if playlist["index"] < 0:
        playlist["index"] = 0
    prev_i = playlist["index"] - 1
    if prev_i < 0:
        if playlist["loop"]:
            prev_i = len(playlist["items"]) - 1
        else:
            return JSONResponse(status_code=400, content={"ok": False, "error": "Inizio playlist"})
    playlist["index"] = prev_i
    prev_path = playlist["items"][prev_i]
    print(f"[PLAYLIST] PREV -> index={prev_i} file={prev_path}", flush=True)
    start_play_with_path(prev_path)
    return {"ok": True, "current": prev_path, "index": prev_i}

# Rimosso endpoint /playlist/take: NEXT/PREV avviano direttamente la riproduzione

@app.post("/playlist/loop")
def api_playlist_loop(on: int = Query(1)):
    playlist["loop"] = (on == 1)
    return {"ok": True, "loop": playlist["loop"]}

@app.post("/update")
def update_apply(restart: bool = Body(True, embed=True), start_at: Optional[float] = Body(None, embed=True)):
    pkg = APP_DIR / "update_pkg.bin"
    if not pkg.exists():
        return JSONResponse(status_code=400, content={"ok": False, "error": "Nessun pacchetto scaricato"})
    current_update["status"] = "applying"
    if start_at:
        delay = max(0.0, float(start_at) - time.time())
        if delay > 0:
            log_update(f"Apply programmata tra {delay:.2f}s (start_at)")
            time.sleep(delay)
    log_update("Applico update…")
    try:
        apply_update(pkg)
        pkg.unlink(missing_ok=True)
        if (APP_DIR/"VERSION").exists():
            global VERSION
            VERSION = (APP_DIR/"VERSION").read_text().strip()
        current_update["status"] = "ok"
        log_update("Update applicato con successo")
        if restart:
            log_update("Riavvio servizio…")
            os._exit(0)
        return {"ok": True}
    except Exception as e:
        current_update["status"] = "error"
        log_update(f"Errore apply: {e}")
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})

@app.post("/maintenance/run_setup")
def api_run_setup(force: bool = Body(False, embed=True)):
    if maintenance["status"] == "running" and not force:
        return JSONResponse(status_code=409, content={"ok": False, "error": "setup già in esecuzione"})
    setup_path = str(APP_DIR / "setup.sh")
    if not os.path.exists(setup_path):
        return JSONResponse(status_code=404, content={"ok": False, "error": "setup.sh non trovato"})
    maintenance["status"] = "running"; maintenance["error"] = None
    log_maintenance("Avvio setup.sh…")

    def worker():
        try:
            # Assicurati che sia eseguibile
            try:
                os.chmod(setup_path, 0o755)
            except Exception:
                pass
            # Esegui direttamente lo script con sudo (richiede regola sudoers specifica)
            cmd = ["sudo", "-n", setup_path]
            try:
                p = subprocess.Popen(cmd, cwd=str(APP_DIR), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            except Exception:
                # Fallback: prova con sudo bash PATH (se sudoers permette bash)
                p = subprocess.Popen(["sudo", "-n", "/bin/bash", setup_path], cwd=str(APP_DIR), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            assert p.stdout is not None
            for line in p.stdout:
                log_maintenance(line.rstrip())
            rc = p.wait()
            if rc == 0:
                maintenance["status"] = "ok"; log_maintenance("setup.sh completato con successo")
            else:
                maintenance["status"] = "error"; maintenance["error"] = f"exit code {rc}"; log_maintenance(f"setup.sh terminato con errore (rc={rc})")
        except Exception as e:
            maintenance["status"] = "error"; maintenance["error"] = str(e); log_maintenance(f"Errore esecuzione setup: {e}")

    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, "status": maintenance["status"]}

@app.get("/maintenance/status")
def api_maintenance_status():
    return {"ok": True, "status": maintenance["status"], "error": maintenance["error"], "last_logs": maintenance["log"][-50:]}

@app.post("/system/reboot")
def system_reboot():
    try:
        threading.Thread(target=lambda: (time.sleep(0.3), os.system("sudo -n reboot || reboot")), daemon=True).start()
        return {"ok": True, "message": "Rebooting"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=APP_PORT)


# .\.venv\bin\activate
