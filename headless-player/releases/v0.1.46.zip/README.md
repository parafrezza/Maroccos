# Headless Video Player (Raspberry Pi 3B)

Riproduttore headless controllato via API FastAPI.

Funzionalità principali:
- Splash iniziale con IP + versione (GStreamer `appsrc`).
	- Ora mostra separatamente: `eth -> <ip>` e `wifi -> <ip>` più `Versione: vX.Y.Z`.
- Opzione splash nero pieno per coprire prompt (SPLASH_BLACK=1). Default disattivo (0) per mantenere lo splash testuale.
- Riproduzione file video (MP4/H.264, MKV, AVI) con validazione header.
- Fade in/out (brightness `videobalance`).
- Loop singolo o playlist multi-file.
- Playlist automatica di tutti i file in `media/` con avanzamento e comandi next/prev.
- Download asset remoto in `media/` con controllo header.
- Sistema di update remoto (pacchetto zip) con tracking bytes.
- Selezione file da riprodurre via path o filename.

## Installazione rapida (su Raspberry Pi)

## Installazione rapida (su Raspberry Pi)

```bash
git clone <questa-repo> headless-player
cd headless-player
sudo chmod +x setup.sh
# Modifica in setup.sh SSID/PASSWORD Wi-Fi se necessario
sudo ./setup.sh
sudo systemctl start headless-player
# (opzione) riavvia per applicare HDMI/rete
sudo reboot
```

## API principali

Base URL tipico: `http://<ip_raspberry>:8080`

### Stato e salute
- `GET /healthz` → stato rapido.
- `GET /status` → dettagli: player state, update, progressi, bytes, manutenzione.
- `POST /ping?duration_ms=120` → risponde subito e provoca un lampo visivo rapido sul device.

Campi principali in `/status`:
```
update_status: downloading|downloaded|applying|ok|error
update_progress: 0-100
update_bytes_done: int
update_bytes_total: int
maintenance_status: idle|running|ok|error
maintenance_last_logs: string
```

### Riproduzione
- `POST /play` body esempio:
```json
{
	"filename": "clip.mp4",
	"loop": false,
	"fade_in_seconds": 0.7,
	"fade_out_seconds": 0.5
}
```
Parametri supportati: `path`, `filename`, `loop`, `hide_splash_first`, `fade_in_seconds`, `fade_out_seconds`.

- `POST /pause`, `POST /resume`
- `POST /loop?on=1|0`
- `POST /fade_in?seconds=1.0`
- `POST /fade_out?seconds=1.0`
- `POST /fade_out_current` body: `{ "seconds": 1.2 }`
- `POST /hide_splash` → nasconde lo splash se ancora visibile.

### Playlist
- `POST /media/playlist` body: `{ "loop": true }` → crea playlist con tutti i file video validi.
- `POST /playlist/next`
- `POST /playlist/prev`
- `GET /playlist/status`

### Media
 `GET /media` → elenco file con type/header.
 `POST /download_asset` body JSON: `{ "url": "http://server/file.mp4", "filename": "clip.mp4" }`
 `GET /download_asset?url=...&filename=...` (alias compat)
 `POST /media/clear?confirm=1` cancella tutti i contenuti di `media/` (richiede confirm).
 `GET /media/clear?confirm=1` (alias compat)

### Update
### Ping visivo (nuovo)
Endpoint: `POST /ping?duration_ms=120`
- Se il player sta riproducendo, viene applicato un brevissimo “flash” (alpha a 0 → nero, oppure aumento brightness) per ~120ms.
- Se è attivo lo splash, mostra temporaneamente una riga “PING!” sullo splash e poi ripristina lo splash normale.
Parametro: `duration_ms` (default 120ms).

 `POST /download_update` body JSON: `{ "url": "http://server/releases/latest.zip", "version": "v0.x.y", "callback_url": "http://host/callback" }`
 `GET /download_update?url=...&version=...&callback_url=...` (alternativo)
### Impostazioni runtime
- `POST /settings/reload` body esempio:
 `GET /network/ethernet/status` → info nmcli e indirizzi IPv4.
 `POST /network/ethernet/config` body: `{ "ip_cidr": "192.168.1.50/24", "gateway": "", "dns": "" }`
```json
{
 Sincronizza media: pulisce media sui device e scarica tutti i file dal server; verifica nomi e dimensioni.
 Invia comando `/download_update` (POST JSON o GET) e traccia avanzamento con bytes e percentuale.
 Applica update (`/update`).
 Rerun del setup via `/maintenance/run_setup`.
	"TARGET_HEIGHT": 720,
	"TARGET_FPS": "25/1",
 Endpoint `POST /playlist/loop?on=1|0` esplicito (attuale: `POST /loop`).
Utile per cambiare sink (KMS vs Auto) e caps senza reboot; se stava riproducendo può ripartire automaticamente.

### Manutenzione remota
- `POST /maintenance/run_setup` body: `{ "force": true }` → rilancia `setup.sh` in background e registra i log.
- `GET /maintenance/status` → stato e ultime righe di log.

## Massive Updater (strumento PC)

Script: `tools/massive_updater.py`
Funzioni:
1. Bump versione + pacchetto zip in `releases/` (aggiorna `latest.zip`).
2. Avvia mini HTTP server (prefisso IP preferito configurabile via `PREFERRED_NET`, default `192.168.1.`).
3. Scopre i player via `/healthz` sulle subnet locali.
4. Invia comando `/download_update` e traccia avanzamento con percentuale/bytes.
5. Applica update (`/update`).
6. (Opzionale) Chiede il rerun del setup via `/maintenance/run_setup` per applicare risoluzione/permessi.

Download atomico: file `.part` rinominato in `update_pkg.bin` a fine download per evitare corruzione.

## Note sicurezza / file
- Validazione header impedisce interpretazione HTML come video.
- Playlist include solo file riconosciuti come video.
- Log limitati (truncate) per non crescere all'infinito.

## Variabili d'ambiente utili
- `USE_KMS` (default 1)
- `USE_HW_DECODER` (default 1)
- `TARGET_WIDTH`/`TARGET_HEIGHT` (default 1280/720)
- `TARGET_FPS` (default "25/1")
- `SPLASH_BLACK` (default 0) → splash nero all'avvio se impostato a 1

## Risoluzione HDMI
`setup.sh` forza di default 1280x720@60 (CEA mode 4). È possibile cambiare gruppo/modo con variabili `HDMI_GROUP` e `HDMI_MODE` prima di lanciare lo script.

## Prossimi miglioramenti possibili
- Hash SHA256 update.
- Cancel / progress watchdog.
- Skip / prev già presenti.

## License
Progetto interno / uso controllato.
