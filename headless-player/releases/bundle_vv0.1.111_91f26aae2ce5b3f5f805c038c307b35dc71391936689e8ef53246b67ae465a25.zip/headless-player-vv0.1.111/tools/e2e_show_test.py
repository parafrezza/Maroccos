"""
End-to-end test: push assets to players, apply playlist (preload first), wait readiness, then trigger faststart go in sync.

Defaults:
- Targets: 192.168.1.167, 192.168.1.204 (override via --targets)
- Media: headless-player/media/testbars_10s.mp4, headless-player/media/testbars_10_TC.mp4 (override via --media)
- Clear-before: true by default (disable via --no-clear)
- Start delay: 5s (override via --delay)

Usage (PowerShell):
  python headless-player/tools/e2e_show_test.py --targets 192.168.1.167 192.168.1.204 --delay 5

This script prints readiness with device IP and name to match the GUI list.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sys
import time
from pathlib import Path
from typing import Iterable, Optional

import requests


DEFAULT_PORT = 8080
TIMEOUT = (2.0, 8.0)  # (connect, read)


def _url(host: str, path: str) -> str:
	if host.startswith("http://") or host.startswith("https://"):
		base = host.rstrip("/")
	else:
		base = f"http://{host}:{DEFAULT_PORT}"
	if not path.startswith("/"):
		path = "/" + path
	return base + path


def _req(host: str, method: str, path: str, *, params=None, json_body=None, files=None, timeout=TIMEOUT):
	url = _url(host, path)
	try:
		r = requests.request(method=method.upper(), url=url, params=params, json=json_body, files=files, timeout=timeout)
		r.raise_for_status()
		try:
			return True, r.json()
		except Exception:
			return True, {"ok": True, "text": r.text}
	except requests.RequestException as e:
		return False, {"ok": False, "error": str(e), "url": url}


def stop(host: str):
	ok, data = _req(host, "POST", "/stop")
	return ok, data


def status(host: str):
	ok, data = _req(host, "GET", "/status")
	return ok, data


def healthz(host: str):
	ok, data = _req(host, "GET", "/healthz")
	return ok, data


def maintenance_fix_permissions(host: str):
	ok, data = _req(host, "POST", "/maintenance/fix_permissions")
	return ok, data


def media_clear(host: str):
	ok, data = _req(host, "POST", "/media/clear", params={"confirm": 1})
	return ok, data


def upload_asset(host: str, local_path: Path, filename: Optional[str] = None):
	if not filename:
		filename = local_path.name
	files = {"file": (filename, open(local_path, "rb"))}
	try:
		ok, data = _req(host, "POST", "/upload_asset", params={"filename": filename}, files=files, timeout=(3.0, 30.0))
		return ok, data
	finally:
		try:
			files["file"][1].close()
		except Exception:
			pass


def playlist_apply(host: str, items: list[str], loop: bool = True):
	body = {"items": items, "loop": loop}
	ok, data = _req(host, "POST", "/playlist/apply", json_body=body)
	return ok, data


def faststart_go(host: str, *, seconds: float = 1.0, in_time: Optional[float] = None):
	params = {"seconds": seconds}
	if in_time is not None:
		params["in_time"] = in_time
	ok, data = _req(host, "POST", "/faststart/go", params=params)
	return ok, data


def wait_states(host: str, states: Iterable[str], timeout_s: float = 5.0, interval: float = 0.25):
	deadline = time.time() + max(0.1, timeout_s)
	states = {s.lower() for s in states}
	last = None
	while time.time() < deadline:
		ok, st = status(host)
		if ok:
			last = st
			ps = str(st.get("player_state") or "").lower()
			if ps in states:
				return True, st
		time.sleep(interval)
	return False, last or {}


def wait_ready(host: str, expected_first: Optional[str], timeout_s: float = 30.0, interval: float = 0.5):
	deadline = time.time() + max(0.1, timeout_s)
	last = None
	while time.time() < deadline:
		ok, st = status(host)
		if ok:
			last = st
			if st.get("show_ready"):
				rf = str(st.get("ready_for") or "")
				if not expected_first or not rf or rf.endswith(Path(expected_first).name):
					return True, st
		time.sleep(interval)
	return False, last or {}


def resolve_media_list(default_paths: list[Path]) -> list[Path]:
	out: list[Path] = []
	for p in default_paths:
		if p.exists() and p.is_file():
			out.append(p)
	return out


def ip_and_name(host: str):
	ip = None; name = None
	ok_h, hz = healthz(host)
	if ok_h:
		ip = hz.get("ip")
	ok_s, st = status(host)
	if ok_s:
		name = st.get("name") or st.get("device_name")
	return ip or host, name or ""


def main(argv: list[str]) -> int:
	parser = argparse.ArgumentParser(description="E2E show test: push → apply → ready → faststart go")
	parser.add_argument("--targets", nargs="+", default=["192.168.1.167", "192.168.1.204"], help="Target player IP/hostnames")
	parser.add_argument("--delay", type=float, default=5.0, help="Start delay seconds for faststart/go")
	parser.add_argument("--no-clear", action="store_true", help="Skip media clear before upload")
	parser.add_argument("--media", nargs="*", default=[], help="Explicit media files to upload (defaults to two testbars)")
	parser.add_argument("--loop", action="store_true", help="Set playlist loop on (default true)")
	parser.add_argument("--no-loop", action="store_true", help="Force playlist loop off")
	args = parser.parse_args(argv)

	# Default media from repo
	repo_root = Path(__file__).resolve().parents[2]
	default_media = [
		repo_root / "headless-player" / "media" / "testbars_10s.mp4",
		repo_root / "headless-player" / "media" / "testbars_10_TC.mp4",
	]
	media_paths = [Path(m) for m in (args.media if args.media else [])]
	if not media_paths:
		media_paths = resolve_media_list(default_media)
	if not media_paths:
		print("[E2E] Nessun media valido trovato. Specifica --media.", file=sys.stderr)
		return 2
	first_name = media_paths[0].name

	loop_flag = True
	if args.no_loop:
		loop_flag = False
	elif args.loop:
		loop_flag = True

	print(f"[E2E] Targets: {', '.join(args.targets)}")
	print(f"[E2E] Media: {[p.name for p in media_paths]}")
	print(f"[E2E] Clear before: {not args.no_clear}")
	print(f"[E2E] Loop: {loop_flag}")

	# 1) Stop all
	print("[E2E] STOP tutti i player…")
	with cf.ThreadPoolExecutor(max_workers=min(8, len(args.targets))) as ex:
		list(ex.map(lambda h: stop(h), args.targets))

	# Attendi stato fermo/pausa breve (alcuni backend possono mettere in pausa su nero)
	for h in args.targets:
		ok, st = wait_states(h, states=("stopped", "paused"), timeout_s=5.0)
		ip, name = ip_and_name(h)
		print(f"  - {ip} {('[' + name + ']') if name else ''}: state={st.get('player_state')} ok={ok}")

	# 2) Clear media (optional)
	if not args.no_clear:
		print("[E2E] Svuoto media sui device…")
		for h in args.targets:
			ok, res = media_clear(h)
			if not ok:
				print(f"  - {h}: clear fallito: {res.get('error')}")
			else:
				print(f"  - {h}: clear ok")

	# 3) Upload assets to each host (in parallel)
	print("[E2E] Upload asset sui device…")
	def _upload_all_for_host(h: str):
		results = []
		for p in media_paths:
			ok, res = upload_asset(h, p, filename=p.name)
			if not ok and "Permesso negato" in str(res.get("error", "")):
				# Prova a riparare permessi e ritenta una volta
				maintenance_fix_permissions(h)
				time.sleep(0.5)
				ok, res = upload_asset(h, p, filename=p.name)
			results.append((p.name, ok, res))
		return h, results

	uploads = []
	with cf.ThreadPoolExecutor(max_workers=min(8, len(args.targets))) as ex:
		for h, results in ex.map(_upload_all_for_host, args.targets):
			uploads.append((h, results))
	for h, results in uploads:
		ip, name = ip_and_name(h)
		for fname, ok, res in results:
			print(f"  - {ip} {('[' + name + ']') if name else ''}: {fname} -> {'ok' if ok else 'FAIL'} {res.get('error','')}")

	# 4) Apply playlist on each host
	print("[E2E] Applico playlist e preparo il primo elemento (faststart)…")
	items = [p.name for p in media_paths]
	for h in args.targets:
		ok, res = playlist_apply(h, items, loop=loop_flag)
		ip, name = ip_and_name(h)
		if ok:
			print(f"  - {ip} {('[' + name + ']') if name else ''}: prepared={Path(res.get('prepared','') or '').name}")
		else:
			print(f"  - {ip} {('[' + name + ']') if name else ''}: FAIL apply: {res.get('error')}")

	# 5) Wait readiness on all
	print("[E2E] Attendo readiness show (tutti i device)…")
	all_ready = True
	for h in args.targets:
		ok, st = wait_ready(h, expected_first=first_name, timeout_s=30.0)
		ip, name = ip_and_name(h)
		rf = st.get("ready_for")
		print(f"  - {ip} {('[' + name + ']') if name else ''}: ready={st.get('show_ready')} for={Path(str(rf)).name if rf else '-'} ok={ok}")
		if not ok:
			all_ready = False

	if not all_ready:
		print("[E2E] NON tutti i device sono pronti. Interrompo qui.")
		return 3

	# 6) Trigger faststart go synchronously with delay
	delay = max(0.0, float(args.delay))
	in_time = time.time() + delay
	print(f"[E2E] LANCIO SHOW tra {delay:.1f}s (epoch={in_time:.3f})…")
	for h in args.targets:
		ok, res = faststart_go(h, seconds=1.0, in_time=in_time)
		ip, name = ip_and_name(h)
		print(f"  - {ip} {('[' + name + ']') if name else ''}: faststart_go -> {'ok' if ok else 'FAIL'}")

	print("[E2E] Fatto.")
	return 0


if __name__ == "__main__":
	raise SystemExit(main(sys.argv[1:]))

