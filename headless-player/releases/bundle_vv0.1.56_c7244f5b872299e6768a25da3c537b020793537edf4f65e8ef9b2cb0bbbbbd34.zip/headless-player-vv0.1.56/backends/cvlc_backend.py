"""Backend che controlla un'istanza esterna di cvlc tramite HTTP."""

from __future__ import annotations

import threading
from importlib import import_module
from pathlib import Path
from typing import Any

from . import register

_cvlc_module = import_module("cvlc_controller")
CvlcController = getattr(_cvlc_module, "CvlcController")
VlcError = getattr(_cvlc_module, "VlcError")


@register("cvlc")
class CvlcBackend:
    """Backend leggero basato su cvlc headless."""

    supports_playlist = False

    def __init__(self, controller: dict) -> None:
        self._globals = controller
        self._lock = threading.Lock()
        self._controller: Any | None = None
        self._loop = False

    # ------------------------------------------------------------------
    # Helpers

    def _current_config(self) -> tuple[str, int, str, str, list[str]]:
        g = self._globals
        host = g.get("VLC_HTTP_HOST", "127.0.0.1")
        port = int(g.get("VLC_HTTP_PORT", 8090))
        user = g.get("VLC_HTTP_USER", "admin")
        password = g.get("VLC_HTTP_PASSWORD", "vlcpass")
        extra_args = list(g.get("VLC_EXTRA_ARGS", []))
        return host, port, user, password, extra_args

    def _get_controller(self):
        host, port, user, password, extra_args = self._current_config()
        with self._lock:
            if self._controller is None:
                self._controller = CvlcController(
                    host=host,
                    port=port,
                    user=user,
                    password=password,
                    extra_args=extra_args,
                )
            else:
                self._controller.reconfigure(host, port, user, password, extra_args)
        self._controller.ensure_running()
        return self._controller

    def _hide_splash(self) -> None:
        splash = self._globals.get("splash")
        if splash and splash.get("active"):
            try:
                self._globals["hide_splash"]()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Backend API
    @property
    def name(self) -> str:
        return "cvlc"

    def play(self, path: str | None = None, loop: bool | None = None, fade_in: float = 0.0) -> None:
        if not path:
            path = self._globals.get("VIDEO_PATH")
        if not path:
            raise RuntimeError("Nessun file specificato per la riproduzione")

        media_path = Path(path)
        if not media_path.exists():
            raise FileNotFoundError(str(media_path))

        controller = self._get_controller()
        final_loop = self._loop if loop is None else bool(loop)
        try:
            controller.play(str(media_path), loop=final_loop, fade_in=fade_in)
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc

        self._loop = final_loop
        self._globals["VIDEO_PATH"] = str(media_path)
        self._globals["player"]["state"] = "playing"
        self._hide_splash()

    def stop(self) -> None:
        controller = self._get_controller()
        try:
            controller.stop()
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc
        self._globals["player"]["state"] = "stopped"

    def pause(self) -> None:
        controller = self._get_controller()
        try:
            controller.pause()
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc
        self._globals["player"]["state"] = "paused"

    def resume(self) -> None:
        controller = self._get_controller()
        try:
            controller.resume()
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc
        self._globals["player"]["state"] = "playing"

    def set_loop(self, enabled: bool) -> None:
        controller = self._get_controller()
        self._loop = bool(enabled)
        try:
            controller.set_loop(self._loop)
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc

    def fade_out(self, seconds: float) -> None:
        controller = self._get_controller()
        try:
            controller.fade_out(seconds)
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc

    def fade_in(self, seconds: float) -> None:
        controller = self._get_controller()
        try:
            controller.fade_in(seconds)
        except VlcError as exc:
            raise RuntimeError(str(exc)) from exc

    def is_playing(self) -> bool:
        try:
            return self._get_controller().is_playing()
        except RuntimeError:
            return False

    def shutdown(self) -> None:
        with self._lock:
            if self._controller is None:
                return
            controller = self._controller
            self._controller = None
        controller.shutdown()
